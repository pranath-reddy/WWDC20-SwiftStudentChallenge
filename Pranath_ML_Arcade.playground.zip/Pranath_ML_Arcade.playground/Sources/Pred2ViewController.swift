import UIKit
import PlaygroundSupport
import Vision
import CoreML

public class Pred2ViewController: UIViewController {
    
    let model = emotion()
    let predictLabel = UILabel()
    
    let viewShadow5 = UIView(frame: CGRect(x: 96, y: 104, width: 408, height: 517))
    
    public lazy var blurbgview : UIImageView = {
        let blurbg = UIImage(named: "blur_BG.png")
        let blurbgview = UIImageView(image: blurbg!)
        blurbgview.frame = CGRect(x: 0, y: 0, width: 600, height: 800)
        return blurbgview
    }()
    
    public lazy var seltextview : UIImageView = {
        var seltext = UIImage(named: "select_photo_text.png")
        let seltextview = UIImageView(image: seltext!)
        seltextview.frame = CGRect(x: 172, y: 137, width: 239, height: 15)
        return seltextview
    }()
    
    let test1  = UIImage(named: "tim_happy.jpg")
    let test3  = UIImage(named: "tim_neutral.jpg")
    let test4  = UIImage(named: "tim_angry.jpg")
    let test2  = UIImage(named: "craig.jpg")
    let test5  = UIImage(named: "John.jpg")
    let test6  = UIImage(named: "John2.jpg")
    let test7  = UIImage(named: "hugh_angry.jpg")
    
    public lazy var cambutton: UIButton = {
        let cambutton = UIButton()
        cambutton.frame = CGRect(x: 222, y: 332, width: 159, height: 45)
        cambutton.setImage(UIImage(named: "pred2_select_photo"), for: .normal)
        cambutton.addTarget(self, action: #selector(cambuttontapped(_:)), for: .touchUpInside)
        return cambutton
    }()
    
    public lazy var moodcirc: UIView = {
        let moodcirc = UIView()
        moodcirc.frame = CGRect(x: 272, y: 527, width: 56, height: 56)
        moodcirc.clipsToBounds = true
        moodcirc.layer.cornerRadius = 56/2
        moodcirc.backgroundColor = UIColor(red: 0.92, green: 0.92, blue: 0.92, alpha: 1)
        moodcirc.alpha = 1
        return moodcirc
    }()
    
    public lazy var viewShadow3: UIView = {
        let viewShadow3 = UIView()
        viewShadow3.frame = CGRect(x: 159, y: 148, width: 282, height: 282)
        viewShadow3.backgroundColor = UIColor.white
        viewShadow3.layer.cornerRadius = 20
        viewShadow3.layer.shadowColor = UIColor.darkGray.cgColor
        viewShadow3.layer.shadowOpacity = 0.5
        viewShadow3.layer.shadowOffset = CGSize.zero
        viewShadow3.layer.shadowRadius = 20
        return viewShadow3
    }()
    
    public lazy var viewShadow6: UIView = {
        let viewShadow6 = UIView()
        viewShadow6.frame = CGRect(x: 220, y: 705, width: 162, height: 52)
        viewShadow6.backgroundColor = UIColor.white
        viewShadow6.layer.cornerRadius = 15
        viewShadow6.layer.shadowColor = UIColor.darkGray.cgColor
        viewShadow6.layer.shadowOpacity = 0.5
        viewShadow6.layer.shadowOffset = CGSize.zero
        viewShadow6.layer.shadowRadius = 20
        return viewShadow6
    }()
    
    public lazy var craigbutton: UIButton = {
        let craigbutton = UIButton()
        craigbutton.frame = CGRect(x: 305, y: 177, width: 145, height: 145)
        craigbutton.setImage(UIImage(named: "craig-button.jpeg"), for: .normal)
        craigbutton.addTarget(self, action: #selector(craigbuttontapped(_:)), for: .touchUpInside)
        return craigbutton
    }()
    
    public lazy var tim1button: UIButton = {
        let tim1button = UIButton()
        tim1button.frame = CGRect(x: 146, y: 177, width: 145, height: 145)
        tim1button.setImage(UIImage(named: "tim1-button.jpeg"), for: .normal)
        tim1button.addTarget(self, action: #selector(tim1buttontapped(_:)), for: .touchUpInside)
        return tim1button
    }()
    
    public lazy var tim2button: UIButton = {
        let tim2button = UIButton()
        tim2button.frame = CGRect(x: 246, y: 332, width: 104, height: 104)
        tim2button.setImage(UIImage(named: "tim2-button.jpeg"), for: .normal)
        tim2button.addTarget(self, action: #selector(tim2buttontapped(_:)), for: .touchUpInside)
        return tim2button
    }()
    
    public lazy var tim3button: UIButton = {
        let tim3button = UIButton()
        tim3button.frame = CGRect(x: 362, y: 332, width: 106, height: 106)
        tim3button.setImage(UIImage(named: "tim3-button.jpeg"), for: .normal)
        tim3button.addTarget(self, action: #selector(tim3buttontapped(_:)), for: .touchUpInside)
        return tim3button
    }()
    
    public lazy var john1button: UIButton = {
        let john1button = UIButton()
        john1button.frame = CGRect(x: 146, y: 448, width: 145, height: 145)
        john1button.setImage(UIImage(named: "John-button.jpeg"), for: .normal)
        john1button.addTarget(self, action: #selector(john1buttontapped(_:)), for: .touchUpInside)
        return john1button
    }()
    
    public lazy var john2button: UIButton = {
        let john2button = UIButton()
        john2button.frame = CGRect(x: 133, y: 333, width: 104, height: 104)
        john2button.setImage(UIImage(named: "John2-button.jpeg"), for: .normal)
        john2button.addTarget(self, action: #selector(john2buttontapped(_:)), for: .touchUpInside)
        return john2button
    }()
    
    public lazy var hughbutton: UIButton = {
        let hughbutton = UIButton()
        hughbutton.frame = CGRect(x: 305, y: 448, width: 145, height: 145)
        hughbutton.setImage(UIImage(named: "hugh-button.jpeg"), for: .normal)
        hughbutton.addTarget(self, action: #selector(hughbuttontapped(_:)), for: .touchUpInside)
        return hughbutton
    }()
    
    public lazy var nextbutton: UIButton = {
        let nextbutton = UIButton()
        nextbutton.frame = CGRect(x: 220, y: 639, width: 162, height: 52)
        nextbutton.setImage(UIImage(named: "next_pred"), for: .normal)
        nextbutton.addTarget(self, action: #selector(nextbuttontapped(_:)), for: .touchUpInside)
        return nextbutton
    }()
    
    @objc func nextbuttontapped(_ sender: UIButton){
    let nextview = Win3ViewController()
    navigationController?.pushViewController(nextview, animated: true)
    }
    
    public lazy var retrybutton: UIButton = {
        let retrybutton = UIButton()
        retrybutton.frame = CGRect(x: 220, y: 705, width: 162, height: 52)
        retrybutton.setImage(UIImage(named: "pred2_TRY_AGAIN"), for: .normal)
        retrybutton.addTarget(self, action: #selector(retrybuttontapped(_:)), for: .touchUpInside)
        return retrybutton
    }()
    
    
    @objc func cambuttontapped(_ sender: UIButton){
        
        viewShadow5.backgroundColor = UIColor.white
        viewShadow5.layer.cornerRadius = 20
        viewShadow5.layer.shadowColor = UIColor.darkGray.cgColor
        viewShadow5.layer.shadowOpacity = 0.5
        viewShadow5.layer.shadowOffset = CGSize.zero
        viewShadow5.layer.shadowRadius = 20
            
        blurbgview.isHidden = false
        viewShadow5.isHidden = false
        seltextview.isHidden = false
        craigbutton.isHidden = false
        tim1button.isHidden = false
        tim2button.isHidden = false
        tim3button.isHidden = false
        john1button.isHidden = false
        john2button.isHidden = false
        hughbutton.isHidden = false
        moodcirc.isHidden = false
        
    }
    
    let redView = UIView()
    
    @objc func craigbuttontapped(_ sender: UIButton){
        
        blurbgview.isHidden = true
        viewShadow5.isHidden = true
        seltextview.isHidden = true
        craigbutton.isHidden = true
        tim1button.isHidden = true
        tim2button.isHidden = true
        tim3button.isHidden = true
        john1button.isHidden = true
        john2button.isHidden = true
        hughbutton.isHidden = true
        retrybutton.isHidden = false
        viewShadow6.isHidden = false
        
        let testview = UIImageView(image: test2!)
        let imageheight = CGFloat(300)
        let imagewidth = (test2?.size.width)! * imageheight / (test2?.size.height)!
        testview.frame = CGRect(x: 0, y: 0,width: imagewidth, height:  imageheight)
        testview.center = viewShadow3.center
        testview.clipsToBounds = true
        testview.layer.cornerRadius = 15
        testview.layer.borderColor = UIColor.white.cgColor
        testview.layer.borderWidth = CGFloat(5.0)
        
        let viewShadow4 = UIView(frame: CGRect(x: 0, y: 0,width: imagewidth, height:  imageheight))
        viewShadow4.center = testview.center
        viewShadow4.backgroundColor = UIColor.white
        viewShadow4.layer.cornerRadius = 15
        viewShadow4.layer.shadowColor = UIColor.darkGray.cgColor
        viewShadow4.layer.shadowOpacity = 0.5
        viewShadow4.layer.shadowOffset = CGSize.zero
        viewShadow4.layer.shadowRadius = 15
        view.addSubview(viewShadow4)
        view.addSubview(testview)
        
        let redView = UIView()
        
        let request = VNDetectFaceRectanglesRequest { (req, err) in
             
             if let err = err {
                 print("Failed to detect faces:", err)
                 return
             }
             
             req.results?.forEach({ (res) in
                 
                 DispatchQueue.main.async {
                     
                     let faceObservation = res as? VNFaceObservation
                     
                     
                     let x = imagewidth * faceObservation!.boundingBox.origin.x + ((self.view.frame.width - imagewidth)/2)
                     
                     let x_crop = imagewidth * faceObservation!.boundingBox.origin.x
                     
                     let height = imageheight * faceObservation!.boundingBox.height
                     
                     let y = testview.frame.minY + imageheight * (1 -  faceObservation!.boundingBox.origin.y) - height
                     
                     let width = imagewidth * faceObservation!.boundingBox.width
                     
                     let y_crop = y - testview.frame.minY
                    
                     
                    
                     redView.backgroundColor = .gray
                     redView.alpha = 0.5
                     redView.frame = CGRect(x: x, y: y, width: width, height: height)
                     redView.layer.cornerRadius = 20
                     redView.layer.borderColor = UIColor.yellow.cgColor
                     redView.layer.borderWidth = CGFloat(3.0)
                     
                     let croprect = CGRect(x: x_crop, y: y_crop, width: width, height: height)
                     let faceimage0 = testview.resizableSnapshotView(from: croprect, afterScreenUpdates: true, withCapInsets: UIEdgeInsets.zero)
                     let faceimage = UIImage.View2Img(faceimage0!)
                   
                     let size = CGSize(width: 48, height: 48)
                     guard let buffer = faceimage.resize(to: size)?.pixelBuffer() else { return }
                     guard let result = try? self.model.prediction(image: buffer) else { return }
                     
                     self.predictLabel.text = result.classLabel
                     
                     switch self.predictLabel.text {
                         case "angry"  :
                             print("angry")
                             self.moodcirc.backgroundColor = UIColor(red: 240/255, green: 111/255, blue: 113/255, alpha: 1)
                         case "disgust"  :
                             print("disgust")
                             self.moodcirc.backgroundColor = UIColor(red: 179/255, green: 94/255, blue: 29/255, alpha: 1)
                         case "scared"  :
                             print("scared")
                             self.moodcirc.backgroundColor = UIColor(red: 178/255, green: 118/255, blue: 187/255, alpha: 1)
                         case "happy"  :
                             print("happy")
                             self.moodcirc.backgroundColor = UIColor(red: 115/255, green: 214/255, blue: 98/255, alpha: 1)
                         case "sad"  :
                             print("sad")
                             self.moodcirc.backgroundColor = UIColor(red: 119/255, green: 157/255, blue: 206/255, alpha: 1)
                         case "surprised"  :
                             print("surprised")
                             self.moodcirc.backgroundColor = UIColor(red: 245/255, green: 108/255, blue: 54/255, alpha: 1)
                         case "neutral"  :
                             print("neutral")
                             self.moodcirc.backgroundColor = UIColor(red: 255/255, green: 218/255, blue: 78/255, alpha: 1)
                         default :
                             print( "No face detected")
                             self.moodcirc.backgroundColor = UIColor(red: 0.92, green: 0.92, blue: 0.92, alpha: 1)
                     }

                 }
                 
             })
         }
         
         guard let cgImage = test2?.cgImage else { return }
         
         DispatchQueue.global(qos: .background).async {
             let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
             do {
                 try handler.perform([request])
             } catch let reqErr {
                 print("Failed to perform request:", reqErr)
             }
         }
        
        
        view.addSubview(redView)

    }
    
    @objc func tim1buttontapped(_ sender: UIButton){
        
        blurbgview.isHidden = true
        viewShadow5.isHidden = true
        seltextview.isHidden = true
        craigbutton.isHidden = true
        tim1button.isHidden = true
        tim2button.isHidden = true
        tim3button.isHidden = true
        hughbutton.isHidden = true
        john1button.isHidden = true
        john2button.isHidden = true
        retrybutton.isHidden = false
        viewShadow6.isHidden = false
        
        let testview = UIImageView(image: test1!)
        let imageheight = CGFloat(300)
        let imagewidth = (test1?.size.width)! * imageheight / (test1?.size.height)!
        testview.frame = CGRect(x: 0, y: 0,width: imagewidth, height:  imageheight)
        testview.center = viewShadow3.center
        testview.clipsToBounds = true
        testview.layer.cornerRadius = 15
        testview.layer.borderColor = UIColor.white.cgColor
        testview.layer.borderWidth = CGFloat(5.0)
        
        let viewShadow4 = UIView(frame: CGRect(x: 0, y: 0,width: imagewidth, height:  imageheight))
        viewShadow4.center = testview.center
        viewShadow4.backgroundColor = UIColor.white
        viewShadow4.layer.cornerRadius = 15
        viewShadow4.layer.shadowColor = UIColor.darkGray.cgColor
        viewShadow4.layer.shadowOpacity = 0.5
        viewShadow4.layer.shadowOffset = CGSize.zero
        viewShadow4.layer.shadowRadius = 15
        view.addSubview(viewShadow4)
        view.addSubview(testview)
        
        let redView = UIView()
        
        let request = VNDetectFaceRectanglesRequest { (req, err) in
             
             if let err = err {
                 print("Failed to detect faces:", err)
                 return
             }
             
             req.results?.forEach({ (res) in
                 
                 DispatchQueue.main.async {
                     
                     let faceObservation = res as? VNFaceObservation
                     
                     
                     let x = imagewidth * faceObservation!.boundingBox.origin.x + ((self.view.frame.width - imagewidth)/2)
                     
                     let x_crop = imagewidth * faceObservation!.boundingBox.origin.x
                     
                     let height = imageheight * faceObservation!.boundingBox.height
                     
                     let y = testview.frame.minY + imageheight * (1 -  faceObservation!.boundingBox.origin.y) - height
                     
                     let width = imagewidth * faceObservation!.boundingBox.width
                     
                     let y_crop = y - testview.frame.minY
                    
                     
                     redView.backgroundColor = .gray
                     redView.alpha = 0.5
                     redView.frame = CGRect(x: x, y: y, width: width, height: height)
                     redView.layer.cornerRadius = 20
                     redView.layer.borderColor = UIColor.yellow.cgColor
                     redView.layer.borderWidth = CGFloat(3.0)
                     
                     let croprect = CGRect(x: x_crop, y: y_crop, width: width, height: height)
                     let faceimage0 = testview.resizableSnapshotView(from: croprect, afterScreenUpdates: true, withCapInsets: UIEdgeInsets.zero)
                     let faceimage = UIImage.View2Img(faceimage0!)
                   
                     let size = CGSize(width: 48, height: 48)
                     guard let buffer = faceimage.resize(to: size)?.pixelBuffer() else { return }
                     guard let result = try? self.model.prediction(image: buffer) else { return }
                     
                     self.predictLabel.text = result.classLabel
                     
                     switch self.predictLabel.text {
                         case "angry"  :
                             print("angry")
                             self.moodcirc.backgroundColor = UIColor(red: 240/255, green: 111/255, blue: 113/255, alpha: 1)
                         case "disgust"  :
                             print("disgust")
                             self.moodcirc.backgroundColor = UIColor(red: 179/255, green: 94/255, blue: 29/255, alpha: 1)
                         case "scared"  :
                             print("scared")
                             self.moodcirc.backgroundColor = UIColor(red: 178/255, green: 118/255, blue: 187/255, alpha: 1)
                         case "happy"  :
                             print("happy")
                             self.moodcirc.backgroundColor = UIColor(red: 115/255, green: 214/255, blue: 98/255, alpha: 1)
                         case "sad"  :
                             print("sad")
                             self.moodcirc.backgroundColor = UIColor(red: 119/255, green: 157/255, blue: 206/255, alpha: 1)
                         case "surprised"  :
                             print("surprised")
                             self.moodcirc.backgroundColor = UIColor(red: 245/255, green: 108/255, blue: 54/255, alpha: 1)
                         case "neutral"  :
                             print("neutral")
                             self.moodcirc.backgroundColor = UIColor(red: 255/255, green: 218/255, blue: 78/255, alpha: 1)
                         default :
                             print( "No face detected")
                             self.moodcirc.backgroundColor = UIColor(red: 0.92, green: 0.92, blue: 0.92, alpha: 1)
                     }

                 }
                 
             })
         }
         
         guard let cgImage = test1?.cgImage else { return }
         
         DispatchQueue.global(qos: .background).async {
             let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
             do {
                 try handler.perform([request])
             } catch let reqErr {
                 print("Failed to perform request:", reqErr)
             }
         }
        
        
        view.addSubview(redView)

    }
    
    @objc func tim2buttontapped(_ sender: UIButton){
        
        blurbgview.isHidden = true
        viewShadow5.isHidden = true
        seltextview.isHidden = true
        craigbutton.isHidden = true
        tim1button.isHidden = true
        tim2button.isHidden = true
        tim3button.isHidden = true
        hughbutton.isHidden = true
        john1button.isHidden = true
        john2button.isHidden = true
        retrybutton.isHidden = false
        viewShadow6.isHidden = false
        
        let testview = UIImageView(image: test3!)
        let imageheight = CGFloat(300)
        let imagewidth = (test3?.size.width)! * imageheight / (test3?.size.height)!
        testview.frame = CGRect(x: 0, y: 0,width: imagewidth, height:  imageheight)
        testview.center = viewShadow3.center
        testview.clipsToBounds = true
        testview.layer.cornerRadius = 15
        testview.layer.borderColor = UIColor.white.cgColor
        testview.layer.borderWidth = CGFloat(5.0)
        
        let viewShadow4 = UIView(frame: CGRect(x: 0, y: 0,width: imagewidth, height:  imageheight))
        viewShadow4.center = testview.center
        viewShadow4.backgroundColor = UIColor.white
        viewShadow4.layer.cornerRadius = 15
        viewShadow4.layer.shadowColor = UIColor.darkGray.cgColor
        viewShadow4.layer.shadowOpacity = 0.5
        viewShadow4.layer.shadowOffset = CGSize.zero
        viewShadow4.layer.shadowRadius = 15
        view.addSubview(viewShadow4)
        view.addSubview(testview)
        
        let redView = UIView()
        
        let request = VNDetectFaceRectanglesRequest { (req, err) in
             
             if let err = err {
                 print("Failed to detect faces:", err)
                 return
             }
             
             req.results?.forEach({ (res) in
                 
                 DispatchQueue.main.async {
                     
                     let faceObservation = res as? VNFaceObservation
                     
                     
                     let x = imagewidth * faceObservation!.boundingBox.origin.x + ((self.view.frame.width - imagewidth)/2)
                     
                     let x_crop = imagewidth * faceObservation!.boundingBox.origin.x
                     
                     let height = imageheight * faceObservation!.boundingBox.height
                     
                     let y = testview.frame.minY + imageheight * (1 -  faceObservation!.boundingBox.origin.y) - height
                     
                     let width = imagewidth * faceObservation!.boundingBox.width
                     
                     let y_crop = y - testview.frame.minY
                    
                     
                     redView.backgroundColor = .gray
                     redView.alpha = 0.5
                     redView.frame = CGRect(x: x, y: y, width: width, height: height)
                     redView.layer.cornerRadius = 20
                     redView.layer.borderColor = UIColor.yellow.cgColor
                     redView.layer.borderWidth = CGFloat(3.0)
                     
                     let croprect = CGRect(x: x_crop, y: y_crop, width: width, height: height)
                     let faceimage0 = testview.resizableSnapshotView(from: croprect, afterScreenUpdates: true, withCapInsets: UIEdgeInsets.zero)
                     let faceimage = UIImage.View2Img(faceimage0!)
                   
                     let size = CGSize(width: 48, height: 48)
                     guard let buffer = faceimage.resize(to: size)?.pixelBuffer() else { return }
                     guard let result = try? self.model.prediction(image: buffer) else { return }
                     
                     self.predictLabel.text = result.classLabel
                     
                     switch self.predictLabel.text {
                         case "angry"  :
                             print("angry")
                             self.moodcirc.backgroundColor = UIColor(red: 240/255, green: 111/255, blue: 113/255, alpha: 1)
                         case "disgust"  :
                             print("disgust")
                             self.moodcirc.backgroundColor = UIColor(red: 179/255, green: 94/255, blue: 29/255, alpha: 1)
                         case "scared"  :
                             print("scared")
                             self.moodcirc.backgroundColor = UIColor(red: 178/255, green: 118/255, blue: 187/255, alpha: 1)
                         case "happy"  :
                             print("happy")
                             self.moodcirc.backgroundColor = UIColor(red: 115/255, green: 214/255, blue: 98/255, alpha: 1)
                         case "sad"  :
                             print("sad")
                             self.moodcirc.backgroundColor = UIColor(red: 119/255, green: 157/255, blue: 206/255, alpha: 1)
                         case "surprised"  :
                             print("surprised")
                             self.moodcirc.backgroundColor = UIColor(red: 245/255, green: 108/255, blue: 54/255, alpha: 1)
                         case "neutral"  :
                             print("neutral")
                             self.moodcirc.backgroundColor = UIColor(red: 255/255, green: 218/255, blue: 78/255, alpha: 1)
                         default :
                             print( "No face detected")
                             self.moodcirc.backgroundColor = UIColor(red: 0.92, green: 0.92, blue: 0.92, alpha: 1)
                     }

                 }
                 
             })
         }
         
         guard let cgImage = test3?.cgImage else { return }
         
         DispatchQueue.global(qos: .background).async {
             let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
             do {
                 try handler.perform([request])
             } catch let reqErr {
                 print("Failed to perform request:", reqErr)
             }
         }
        
        
        view.addSubview(redView)

    }
    
    @objc func tim3buttontapped(_ sender: UIButton){
        
        blurbgview.isHidden = true
        viewShadow5.isHidden = true
        seltextview.isHidden = true
        craigbutton.isHidden = true
        tim1button.isHidden = true
        tim2button.isHidden = true
        tim3button.isHidden = true
        hughbutton.isHidden = true
        john1button.isHidden = true
        john2button.isHidden = true
        retrybutton.isHidden = false
        viewShadow6.isHidden = false
        
        let testview = UIImageView(image: test4!)
        let imageheight = CGFloat(300)
        let imagewidth = (test4?.size.width)! * imageheight / (test4?.size.height)!
        testview.frame = CGRect(x: 0, y: 0,width: imagewidth, height:  imageheight)
        testview.center = viewShadow3.center
        testview.clipsToBounds = true
        testview.layer.cornerRadius = 15
        testview.layer.borderColor = UIColor.white.cgColor
        testview.layer.borderWidth = CGFloat(5.0)
        
        let viewShadow4 = UIView(frame: CGRect(x: 0, y: 0,width: imagewidth, height:  imageheight))
        viewShadow4.center = testview.center
        viewShadow4.backgroundColor = UIColor.white
        viewShadow4.layer.cornerRadius = 15
        viewShadow4.layer.shadowColor = UIColor.darkGray.cgColor
        viewShadow4.layer.shadowOpacity = 0.5
        viewShadow4.layer.shadowOffset = CGSize.zero
        viewShadow4.layer.shadowRadius = 15
        view.addSubview(viewShadow4)
        view.addSubview(testview)
        
        let redView = UIView()
        
        let request = VNDetectFaceRectanglesRequest { (req, err) in
             
             if let err = err {
                 print("Failed to detect faces:", err)
                 return
             }
             
             req.results?.forEach({ (res) in
                 
                 DispatchQueue.main.async {
                     
                     let faceObservation = res as? VNFaceObservation
                     
                     
                     let x = imagewidth * faceObservation!.boundingBox.origin.x + ((self.view.frame.width - imagewidth)/2)
                     
                     let x_crop = imagewidth * faceObservation!.boundingBox.origin.x
                     
                     let height = imageheight * faceObservation!.boundingBox.height
                     
                     let y = testview.frame.minY + imageheight * (1 -  faceObservation!.boundingBox.origin.y) - height
                     
                     let width = imagewidth * faceObservation!.boundingBox.width
                     
                     let y_crop = y - testview.frame.minY
                    
                     
                     redView.backgroundColor = .gray
                     redView.alpha = 0.5
                     redView.frame = CGRect(x: x, y: y, width: width, height: height)
                     redView.layer.cornerRadius = 20
                     redView.layer.borderColor = UIColor.yellow.cgColor
                     redView.layer.borderWidth = CGFloat(3.0)
                     
                     let croprect = CGRect(x: x_crop, y: y_crop, width: width, height: height)
                     let faceimage0 = testview.resizableSnapshotView(from: croprect, afterScreenUpdates: true, withCapInsets: UIEdgeInsets.zero)
                     let faceimage = UIImage.View2Img(faceimage0!)
                   
                     let size = CGSize(width: 48, height: 48)
                     guard let buffer = faceimage.resize(to: size)?.pixelBuffer() else { return }
                     guard let result = try? self.model.prediction(image: buffer) else { return }
                     
                     self.predictLabel.text = result.classLabel
                     
                     switch self.predictLabel.text {
                         case "angry"  :
                             print("angry")
                             self.moodcirc.backgroundColor = UIColor(red: 240/255, green: 111/255, blue: 113/255, alpha: 1)
                         case "disgust"  :
                             print("disgust")
                             self.moodcirc.backgroundColor = UIColor(red: 179/255, green: 94/255, blue: 29/255, alpha: 1)
                         case "scared"  :
                             print("scared")
                             self.moodcirc.backgroundColor = UIColor(red: 178/255, green: 118/255, blue: 187/255, alpha: 1)
                         case "happy"  :
                             print("happy")
                             self.moodcirc.backgroundColor = UIColor(red: 115/255, green: 214/255, blue: 98/255, alpha: 1)
                         case "sad"  :
                             print("sad")
                             self.moodcirc.backgroundColor = UIColor(red: 119/255, green: 157/255, blue: 206/255, alpha: 1)
                         case "surprised"  :
                             print("surprised")
                             self.moodcirc.backgroundColor = UIColor(red: 245/255, green: 108/255, blue: 54/255, alpha: 1)
                         case "neutral"  :
                             print("neutral")
                             self.moodcirc.backgroundColor = UIColor(red: 255/255, green: 218/255, blue: 78/255, alpha: 1)
                         default :
                             print( "No face detected")
                             self.moodcirc.backgroundColor = UIColor(red: 0.92, green: 0.92, blue: 0.92, alpha: 1)
                     }

                 }
                 
             })
         }
         
         guard let cgImage = test4?.cgImage else { return }
         
         DispatchQueue.global(qos: .background).async {
             let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
             do {
                 try handler.perform([request])
             } catch let reqErr {
                 print("Failed to perform request:", reqErr)
             }
         }
        
        
        view.addSubview(redView)

    }
    
    @objc func john1buttontapped(_ sender: UIButton){
        
        blurbgview.isHidden = true
        viewShadow5.isHidden = true
        seltextview.isHidden = true
        craigbutton.isHidden = true
        tim1button.isHidden = true
        tim2button.isHidden = true
        tim3button.isHidden = true
        hughbutton.isHidden = true
        retrybutton.isHidden = false
        viewShadow6.isHidden = false
        john1button.isHidden = true
        john2button.isHidden = true
        
        let testview = UIImageView(image: test5!)
        let imageheight = CGFloat(300)
        let imagewidth = (test5?.size.width)! * imageheight / (test5?.size.height)!
        testview.frame = CGRect(x: 0, y: 0,width: imagewidth, height:  imageheight)
        testview.center = viewShadow3.center
        testview.clipsToBounds = true
        testview.layer.cornerRadius = 15
        testview.layer.borderColor = UIColor.white.cgColor
        testview.layer.borderWidth = CGFloat(5.0)
        
        let viewShadow4 = UIView(frame: CGRect(x: 0, y: 0,width: imagewidth, height:  imageheight))
        viewShadow4.center = testview.center
        viewShadow4.backgroundColor = UIColor.white
        viewShadow4.layer.cornerRadius = 15
        viewShadow4.layer.shadowColor = UIColor.darkGray.cgColor
        viewShadow4.layer.shadowOpacity = 0.5
        viewShadow4.layer.shadowOffset = CGSize.zero
        viewShadow4.layer.shadowRadius = 15
        view.addSubview(viewShadow4)
        view.addSubview(testview)
        
        let redView = UIView()
        
        let request = VNDetectFaceRectanglesRequest { (req, err) in
             
             if let err = err {
                 print("Failed to detect faces:", err)
                 return
             }
             
             req.results?.forEach({ (res) in
                 
                 DispatchQueue.main.async {
                     
                     let faceObservation = res as? VNFaceObservation
                     
                     
                     let x = imagewidth * faceObservation!.boundingBox.origin.x + ((self.view.frame.width - imagewidth)/2)
                     
                     let x_crop = imagewidth * faceObservation!.boundingBox.origin.x
                     
                     let height = imageheight * faceObservation!.boundingBox.height
                     
                     let y = testview.frame.minY + imageheight * (1 -  faceObservation!.boundingBox.origin.y) - height
                     
                     let width = imagewidth * faceObservation!.boundingBox.width
                     
                     let y_crop = y - testview.frame.minY
                    
                     
                     redView.backgroundColor = .gray
                     redView.alpha = 0.5
                     redView.frame = CGRect(x: x, y: y, width: width, height: height)
                     redView.layer.cornerRadius = 20
                     redView.layer.borderColor = UIColor.yellow.cgColor
                     redView.layer.borderWidth = CGFloat(3.0)
                     
                     let croprect = CGRect(x: x_crop, y: y_crop, width: width, height: height)
                     let faceimage0 = testview.resizableSnapshotView(from: croprect, afterScreenUpdates: true, withCapInsets: UIEdgeInsets.zero)
                     let faceimage = UIImage.View2Img(faceimage0!)
                   
                     let size = CGSize(width: 48, height: 48)
                     guard let buffer = faceimage.resize(to: size)?.pixelBuffer() else { return }
                     guard let result = try? self.model.prediction(image: buffer) else { return }
                     
                     self.predictLabel.text = result.classLabel
                     
                     switch self.predictLabel.text {
                         case "angry"  :
                             print("angry")
                             self.moodcirc.backgroundColor = UIColor(red: 240/255, green: 111/255, blue: 113/255, alpha: 1)
                         case "disgust"  :
                             print("disgust")
                             self.moodcirc.backgroundColor = UIColor(red: 179/255, green: 94/255, blue: 29/255, alpha: 1)
                         case "scared"  :
                             print("scared")
                             self.moodcirc.backgroundColor = UIColor(red: 178/255, green: 118/255, blue: 187/255, alpha: 1)
                         case "happy"  :
                             print("happy")
                             self.moodcirc.backgroundColor = UIColor(red: 115/255, green: 214/255, blue: 98/255, alpha: 1)
                         case "sad"  :
                             print("sad")
                             self.moodcirc.backgroundColor = UIColor(red: 119/255, green: 157/255, blue: 206/255, alpha: 1)
                         case "surprised"  :
                             print("surprised")
                             self.moodcirc.backgroundColor = UIColor(red: 245/255, green: 108/255, blue: 54/255, alpha: 1)
                         case "neutral"  :
                             print("neutral")
                             self.moodcirc.backgroundColor = UIColor(red: 255/255, green: 218/255, blue: 78/255, alpha: 1)
                         default :
                             print( "No face detected")
                             self.moodcirc.backgroundColor = UIColor(red: 0.92, green: 0.92, blue: 0.92, alpha: 1)
                     }

                 }
                 
             })
         }
         
         guard let cgImage = test5?.cgImage else { return }
         
         DispatchQueue.global(qos: .background).async {
             let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
             do {
                 try handler.perform([request])
             } catch let reqErr {
                 print("Failed to perform request:", reqErr)
             }
         }
        
        
        view.addSubview(redView)

    }
    
    @objc func john2buttontapped(_ sender: UIButton){
        
        blurbgview.isHidden = true
        viewShadow5.isHidden = true
        seltextview.isHidden = true
        craigbutton.isHidden = true
        tim1button.isHidden = true
        tim2button.isHidden = true
        tim3button.isHidden = true
        john1button.isHidden = true
        john2button.isHidden = true
        hughbutton.isHidden = true
        retrybutton.isHidden = false
        viewShadow6.isHidden = false
        
        let testview = UIImageView(image: test6!)
        let imageheight = CGFloat(300)
        let imagewidth = (test6?.size.width)! * imageheight / (test6?.size.height)!
        testview.frame = CGRect(x: 0, y: 0,width: imagewidth, height:  imageheight)
        testview.center = viewShadow3.center
        testview.clipsToBounds = true
        testview.layer.cornerRadius = 15
        testview.layer.borderColor = UIColor.white.cgColor
        testview.layer.borderWidth = CGFloat(5.0)
        
        let viewShadow4 = UIView(frame: CGRect(x: 0, y: 0,width: imagewidth, height:  imageheight))
        viewShadow4.center = testview.center
        viewShadow4.backgroundColor = UIColor.white
        viewShadow4.layer.cornerRadius = 15
        viewShadow4.layer.shadowColor = UIColor.darkGray.cgColor
        viewShadow4.layer.shadowOpacity = 0.5
        viewShadow4.layer.shadowOffset = CGSize.zero
        viewShadow4.layer.shadowRadius = 15
        view.addSubview(viewShadow4)
        view.addSubview(testview)
        
        let redView = UIView()
        
        let request = VNDetectFaceRectanglesRequest { (req, err) in
             
             if let err = err {
                 print("Failed to detect faces:", err)
                 return
             }
             
             req.results?.forEach({ (res) in
                 
                 DispatchQueue.main.async {
                     
                     let faceObservation = res as? VNFaceObservation
                     
                     
                     let x = imagewidth * faceObservation!.boundingBox.origin.x + ((self.view.frame.width - imagewidth)/2)
                     
                     let x_crop = imagewidth * faceObservation!.boundingBox.origin.x
                     
                     let height = imageheight * faceObservation!.boundingBox.height
                     
                     let y = testview.frame.minY + imageheight * (1 -  faceObservation!.boundingBox.origin.y) - height
                     
                     let width = imagewidth * faceObservation!.boundingBox.width
                     
                     let y_crop = y - testview.frame.minY
                    
                     
                     redView.backgroundColor = .gray
                     redView.alpha = 0.5
                     redView.frame = CGRect(x: x, y: y, width: width, height: height)
                     redView.layer.cornerRadius = 20
                     redView.layer.borderColor = UIColor.yellow.cgColor
                     redView.layer.borderWidth = CGFloat(3.0)
                     
                     let croprect = CGRect(x: x_crop, y: y_crop, width: width, height: height)
                     let faceimage0 = testview.resizableSnapshotView(from: croprect, afterScreenUpdates: true, withCapInsets: UIEdgeInsets.zero)
                     let faceimage = UIImage.View2Img(faceimage0!)
                   
                     let size = CGSize(width: 48, height: 48)
                     guard let buffer = faceimage.resize(to: size)?.pixelBuffer() else { return }
                     guard let result = try? self.model.prediction(image: buffer) else { return }
                     
                     self.predictLabel.text = result.classLabel
                     
                     switch self.predictLabel.text {
                         case "angry"  :
                             print("angry")
                             self.moodcirc.backgroundColor = UIColor(red: 240/255, green: 111/255, blue: 113/255, alpha: 1)
                         case "disgust"  :
                             print("disgust")
                             self.moodcirc.backgroundColor = UIColor(red: 179/255, green: 94/255, blue: 29/255, alpha: 1)
                         case "scared"  :
                             print("scared")
                             self.moodcirc.backgroundColor = UIColor(red: 178/255, green: 118/255, blue: 187/255, alpha: 1)
                         case "happy"  :
                             print("happy")
                             self.moodcirc.backgroundColor = UIColor(red: 115/255, green: 214/255, blue: 98/255, alpha: 1)
                         case "sad"  :
                             print("sad")
                             self.moodcirc.backgroundColor = UIColor(red: 119/255, green: 157/255, blue: 206/255, alpha: 1)
                         case "surprised"  :
                             print("surprised")
                             self.moodcirc.backgroundColor = UIColor(red: 245/255, green: 108/255, blue: 54/255, alpha: 1)
                         case "neutral"  :
                             print("neutral")
                             self.moodcirc.backgroundColor = UIColor(red: 255/255, green: 218/255, blue: 78/255, alpha: 1)
                         default :
                             print( "No face detected")
                             self.moodcirc.backgroundColor = UIColor(red: 0.92, green: 0.92, blue: 0.92, alpha: 1)
                     }

                 }
                 
             })
         }
         
         guard let cgImage = test6?.cgImage else { return }
         
         DispatchQueue.global(qos: .background).async {
             let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
             do {
                 try handler.perform([request])
             } catch let reqErr {
                 print("Failed to perform request:", reqErr)
             }
         }
        
        
        view.addSubview(redView)

    }
    
    @objc func hughbuttontapped(_ sender: UIButton){
        
        blurbgview.isHidden = true
        viewShadow5.isHidden = true
        seltextview.isHidden = true
        craigbutton.isHidden = true
        tim1button.isHidden = true
        tim2button.isHidden = true
        tim3button.isHidden = true
        john1button.isHidden = true
        john2button.isHidden = true
        hughbutton.isHidden = true
        retrybutton.isHidden = false
        viewShadow6.isHidden = false
        
        let testview = UIImageView(image: test7!)
        let imageheight = CGFloat(300)
        let imagewidth = (test7?.size.width)! * imageheight / (test7?.size.height)!
        testview.frame = CGRect(x: 0, y: 0,width: imagewidth, height:  imageheight)
        testview.center = viewShadow3.center
        testview.clipsToBounds = true
        testview.layer.cornerRadius = 15
        testview.layer.borderColor = UIColor.white.cgColor
        testview.layer.borderWidth = CGFloat(5.0)
        
        let viewShadow4 = UIView(frame: CGRect(x: 0, y: 0,width: imagewidth, height:  imageheight))
        viewShadow4.center = testview.center
        viewShadow4.backgroundColor = UIColor.white
        viewShadow4.layer.cornerRadius = 15
        viewShadow4.layer.shadowColor = UIColor.darkGray.cgColor
        viewShadow4.layer.shadowOpacity = 0.5
        viewShadow4.layer.shadowOffset = CGSize.zero
        viewShadow4.layer.shadowRadius = 15
        view.addSubview(viewShadow4)
        view.addSubview(testview)
        
        let redView = UIView()
        
        let request = VNDetectFaceRectanglesRequest { (req, err) in
             
             if let err = err {
                 print("Failed to detect faces:", err)
                 return
             }
             
             req.results?.forEach({ (res) in
                 
                 DispatchQueue.main.async {
                     
                     let faceObservation = res as? VNFaceObservation
                     
                     
                     let x = imagewidth * faceObservation!.boundingBox.origin.x + ((self.view.frame.width - imagewidth)/2)
                     
                     let x_crop = imagewidth * faceObservation!.boundingBox.origin.x
                     
                     let height = imageheight * faceObservation!.boundingBox.height
                     
                     let y = testview.frame.minY + imageheight * (1 -  faceObservation!.boundingBox.origin.y) - height
                     
                     let width = imagewidth * faceObservation!.boundingBox.width
                     
                     let y_crop = y - testview.frame.minY
                    
                     
                     redView.backgroundColor = .gray
                     redView.alpha = 0.5
                     redView.frame = CGRect(x: x, y: y, width: width, height: height)
                     redView.layer.cornerRadius = 20
                     redView.layer.borderColor = UIColor.yellow.cgColor
                     redView.layer.borderWidth = CGFloat(3.0)
                     
                     let croprect = CGRect(x: x_crop, y: y_crop, width: width, height: height)
                     let faceimage0 = testview.resizableSnapshotView(from: croprect, afterScreenUpdates: true, withCapInsets: UIEdgeInsets.zero)
                     let faceimage = UIImage.View2Img(faceimage0!)
                   
                     let size = CGSize(width: 48, height: 48)
                     guard let buffer = faceimage.resize(to: size)?.pixelBuffer() else { return }
                     guard let result = try? self.model.prediction(image: buffer) else { return }
                     
                     self.predictLabel.text = result.classLabel
                     
                     switch self.predictLabel.text {
                         case "angry"  :
                             print("angry")
                             self.moodcirc.backgroundColor = UIColor(red: 240/255, green: 111/255, blue: 113/255, alpha: 1)
                         case "disgust"  :
                             print("disgust")
                             self.moodcirc.backgroundColor = UIColor(red: 179/255, green: 94/255, blue: 29/255, alpha: 1)
                         case "scared"  :
                             print("scared")
                             self.moodcirc.backgroundColor = UIColor(red: 178/255, green: 118/255, blue: 187/255, alpha: 1)
                         case "happy"  :
                             print("happy")
                             self.moodcirc.backgroundColor = UIColor(red: 115/255, green: 214/255, blue: 98/255, alpha: 1)
                         case "sad"  :
                             print("sad")
                             self.moodcirc.backgroundColor = UIColor(red: 119/255, green: 157/255, blue: 206/255, alpha: 1)
                         case "surprised"  :
                             print("surprised")
                             self.moodcirc.backgroundColor = UIColor(red: 245/255, green: 108/255, blue: 54/255, alpha: 1)
                         case "neutral"  :
                             print("neutral")
                             self.moodcirc.backgroundColor = UIColor(red: 255/255, green: 218/255, blue: 78/255, alpha: 1)
                         default :
                             print( "No face detected")
                             self.moodcirc.backgroundColor = UIColor(red: 0.92, green: 0.92, blue: 0.92, alpha: 1)
                     }

                 }
                 
             })
         }
         
         guard let cgImage = test7?.cgImage else { return }
         
         DispatchQueue.global(qos: .background).async {
             let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
             do {
                 try handler.perform([request])
             } catch let reqErr {
                 print("Failed to perform request:", reqErr)
             }
         }
        
        
        view.addSubview(redView)

    }
    
    @objc func retrybuttontapped(_ sender: UIButton){
        view.addSubview(blurbgview)
        view.addSubview(viewShadow5)
        view.addSubview(seltextview)
        view.addSubview(craigbutton)
        view.addSubview(tim1button)
        view.addSubview(tim2button)
        view.addSubview(tim3button)
        view.addSubview(john1button)
        view.addSubview(john2button)
        view.addSubview(hughbutton)
        blurbgview.isHidden = false
        viewShadow5.isHidden = false
        seltextview.isHidden = false
        craigbutton.isHidden = false
        tim1button.isHidden = false
        tim2button.isHidden = false
        tim3button.isHidden = false
        john1button.isHidden = false
        john2button.isHidden = false
        hughbutton.isHidden = false
        
    }
    
    public override func viewDidLoad() {
        
        super.viewDidLoad()
        let view = UIView(frame: CGRect(x: 0, y: 0, width: 600, height: 800))
        view.backgroundColor = .white
        view.alpha = 1
        self.view = view
        navigationController?.isNavigationBarHidden = true
                
        let moodShadow = UIView(frame: CGRect(x: 243, y: 483, width: 114, height: 114))
        moodShadow.backgroundColor = UIColor.white
        moodShadow.layer.cornerRadius = 15
        moodShadow.layer.shadowColor = UIColor.darkGray.cgColor
        moodShadow.layer.shadowOpacity = 0.5
        moodShadow.layer.shadowOffset = CGSize.zero
        moodShadow.layer.shadowRadius = 20
        
        let camShadow = UIView(frame: CGRect(x: 222, y: 332, width: 159, height: 45))
        camShadow.backgroundColor = UIColor.white
        camShadow.layer.cornerRadius = 5
        camShadow.layer.shadowColor = UIColor.darkGray.cgColor
        camShadow.layer.shadowOpacity = 0.35
        camShadow.layer.shadowOffset = CGSize.zero
        camShadow.layer.shadowRadius = 20
        
        let buttonrect2 = UIView()
        buttonrect2.frame = CGRect(x: 220, y: 639, width: 162, height: 52)
        buttonrect2.clipsToBounds = true
        buttonrect2.layer.cornerRadius = 15
        buttonrect2.backgroundColor = UIColor(red: 1.00, green: 1.00, blue: 1.00, alpha: 1)
        buttonrect2.alpha = 1
        
        let viewShadow2 = UIView(frame: CGRect(x: 220, y: 639, width: 162, height: 52))
        viewShadow2.center = buttonrect2.center
        viewShadow2.backgroundColor = UIColor.black
        viewShadow2.layer.cornerRadius = 15
        viewShadow2.layer.shadowColor = UIColor.darkGray.cgColor
        viewShadow2.layer.shadowOpacity = 0.5
        viewShadow2.layer.shadowOffset = CGSize.zero
        viewShadow2.layer.shadowRadius = 20
                
        let canvrect = UIView()
        canvrect.frame = CGRect(x: 159, y: 148, width: 282, height: 282)
        canvrect.clipsToBounds = true
        canvrect.layer.cornerRadius = 20
        canvrect.backgroundColor = UIColor(red: 1.00, green: 1.00, blue: 1.00, alpha: 1)
        canvrect.alpha = 1
        
        let arc = UIImage(named: "arc_pred.png")
        let arcview = UIImageView(image: arc!)
        arcview.frame = CGRect(x: 0, y: 4, width: 600, height: 796)
        view.addSubview(arcview)
        
        let faceid = UIImage(named: "Face_ID.png")
        let faceidview = UIImageView(image: faceid!)
        faceidview.frame = CGRect(x: 266, y: 221, width: 70, height: 70)
        
        let title = UIImage(named: "pred2_title.png")
        let titleview = UIImageView(image: title!)
        titleview.frame = CGRect(x: 241, y: 47, width: 114, height: 46)
        view.addSubview(titleview)
        
        let mood = UIImage(named: "mood_title.png")
        let moodview = UIImageView(image: mood!)
        moodview.frame = CGRect(x: 275, y: 499, width: 46, height: 16)
        
        view.addSubview(viewShadow2)
        view.addSubview(viewShadow3)
        view.addSubview(moodShadow)
        view.addSubview(camShadow)
        view.addSubview(moodcirc)
        view.addSubview(buttonrect2)
        view.addSubview(faceidview)
        view.addSubview(titleview)
        view.addSubview(moodview)
        view.addSubview(cambutton)
        view.addSubview(nextbutton)
        view.addSubview(viewShadow6)
        view.addSubview(retrybutton)
        
        view.addSubview(blurbgview)
        view.addSubview(viewShadow5)
        view.addSubview(seltextview)
        view.addSubview(craigbutton)
        view.addSubview(tim1button)
        view.addSubview(tim2button)
        view.addSubview(tim3button)
        view.addSubview(john1button)
        view.addSubview(john2button)
        view.addSubview(hughbutton)
       
        
        blurbgview.isHidden = true
        viewShadow5.isHidden = true
        viewShadow6.isHidden = true
        seltextview.isHidden = true
        craigbutton.isHidden = true
        retrybutton.isHidden = true
        tim1button.isHidden = true
        tim2button.isHidden = true
        tim3button.isHidden = true
        john1button.isHidden = true
        john2button.isHidden = true
        hughbutton.isHidden = true
        moodcirc.isHidden = true
        
    }
    
}

extension UIImage {
    
    class func View2Img(_ view: UIView) -> UIImage {
        UIGraphicsBeginImageContextWithOptions(view.bounds.size, view.isOpaque, 0)
        defer { UIGraphicsEndImageContext() }
        view.drawHierarchy(in: view.bounds, afterScreenUpdates: true)
        return UIGraphicsGetImageFromCurrentImageContext() ?? UIImage()
    }
    
    func pixelBuffer() -> CVPixelBuffer? {
        let width = self.size.width
        let height = self.size.height
        let attrs = [kCVPixelBufferCGImageCompatibilityKey: kCFBooleanTrue,
                     kCVPixelBufferCGBitmapContextCompatibilityKey: kCFBooleanTrue] as CFDictionary
        var pixelBuffer: CVPixelBuffer?
        let status = CVPixelBufferCreate(kCFAllocatorDefault,
                                         Int(width),
                                         Int(height),
                                         kCVPixelFormatType_OneComponent8,
                                         attrs,
                                         &pixelBuffer)
        
        guard let resultPixelBuffer = pixelBuffer, status == kCVReturnSuccess else {
            return nil
        }
        
        CVPixelBufferLockBaseAddress(resultPixelBuffer, CVPixelBufferLockFlags(rawValue: 0))
        let pixelData = CVPixelBufferGetBaseAddress(resultPixelBuffer)
        
        let grayColorSpace = CGColorSpaceCreateDeviceGray()
        guard let context = CGContext(data: pixelData,
                                      width: Int(width),
                                      height: Int(height),
                                      bitsPerComponent: 8,
                                      bytesPerRow: CVPixelBufferGetBytesPerRow(resultPixelBuffer),
                                      space: grayColorSpace,
                                      bitmapInfo: CGImageAlphaInfo.none.rawValue) else {
                                        return nil
        }
        
        context.translateBy(x: 0, y: height)
        context.scaleBy(x: 1.0, y: -1.0)
        
        UIGraphicsPushContext(context)
        self.draw(in: CGRect(x: 0, y: 0, width: width, height: height))
        UIGraphicsPopContext()
        CVPixelBufferUnlockBaseAddress(resultPixelBuffer, CVPixelBufferLockFlags(rawValue: 0))
        
        return resultPixelBuffer
    }
    
    func resize(to newSize: CGSize) -> UIImage? {
        guard self.size != newSize else { return self }
        
        UIGraphicsBeginImageContextWithOptions(newSize, false, 0.0)
        self.draw(in: CGRect(x: 0, y: 0, width: newSize.width, height: newSize.height))
        
        defer { UIGraphicsEndImageContext() }
        return UIGraphicsGetImageFromCurrentImageContext()
    }
}
