import UIKit
import PlaygroundSupport

class InfoViewController: UIViewController {
    
    public lazy var infonextbutton: UIButton = {
        let infonextbutton = UIButton()
        infonextbutton.frame = CGRect(x: 237, y: 701, width: 127, height: 46)
        infonextbutton.setImage(UIImage(named: "info_button"), for: .normal)
        infonextbutton.addTarget(self, action: #selector(infonextbuttontapped(_:)), for: .touchUpInside)
        return infonextbutton
    }()
     
    @objc func infonextbuttontapped(_ sender: UIButton){
        let nextview = WinViewController()
        navigationController?.pushViewController(nextview, animated: true)
    }
    
    override func viewDidLoad() {

        super.viewDidLoad()
        let view = UIView(frame: CGRect(x: 0, y: 0, width: 600, height: 800))
        view.backgroundColor = .white
        view.alpha = 1
        self.view = view
        navigationController?.isNavigationBarHidden = true

        let srect1 = UIView()
        srect1.frame = CGRect(x: 229, y: 174, width: 60, height: 8)
        srect1.clipsToBounds = true
        srect1.layer.cornerRadius = 3
        srect1.backgroundColor = UIColor(red: 0.87, green: 0.91, blue: 0.98, alpha: 1)
        srect1.alpha = 1
        
        let srect2 = UIView()
        srect2.frame = CGRect(x: 229, y: 468, width: 60, height: 7)
        srect2.clipsToBounds = true
        srect2.layer.cornerRadius = 3
        srect2.backgroundColor = UIColor(red: 0.97, green: 0.90, blue: 0.99, alpha: 1)
        srect2.alpha = 1

        let viewShadow = UIView(frame: CGRect(x: 195, y: 94, width: 305, height: 230))
        viewShadow.backgroundColor = UIColor.white
        viewShadow.layer.cornerRadius = 15
        viewShadow.layer.shadowColor = UIColor(red: 0.49, green: 0.76, blue: 0.96, alpha: 0.35).cgColor
        viewShadow.layer.shadowOpacity = 0.8
        viewShadow.layer.shadowOffset = CGSize.zero
        viewShadow.layer.shadowRadius = 20

        let viewShadow2 = UIView(frame: CGRect(x: 195, y: 390, width: 305, height: 230))
        viewShadow2.backgroundColor = UIColor.white
        viewShadow2.layer.cornerRadius = 15
        viewShadow2.layer.shadowColor = UIColor(red: 0.95, green: 0.76, blue: 0.98, alpha: 0.35).cgColor
        viewShadow2.layer.shadowOpacity = 0.9
        viewShadow2.layer.shadowOffset = CGSize.zero
        viewShadow2.layer.shadowRadius = 20

        let viewShadow3 = UIView(frame: CGRect(x: 237, y: 701, width: 127, height: 46))
        viewShadow3.backgroundColor = UIColor.white
        viewShadow3.layer.cornerRadius = 15
        viewShadow3.layer.shadowColor = UIColor.darkGray.cgColor
        viewShadow3.layer.shadowOpacity = 0.3
        viewShadow3.layer.shadowOffset = CGSize.zero
        viewShadow3.layer.shadowRadius = 20

        let title = UIImage(named: "info_title.png")
        let titleview = UIImageView(image: title!)
        titleview.frame = CGRect(x: 216, y: 36, width: 168, height: 14)
        view.addSubview(titleview)

        let i01 = UIImage(named: "01.png")
        let view01 = UIImageView(image: i01!)
        view01.frame = CGRect(x: 100, y: 109, width: 70, height: 74)
        
        let i02 = UIImage(named: "02.png")
        let view02 = UIImageView(image: i02!)
        view02.frame = CGRect(x: 100, y: 405, width: 76, height: 74)
 
        let sec1 = UIImage(named: "section1.png")
        let sec1view = UIImageView(image: sec1!)
        sec1view.frame = CGRect(x: 229, y: 144, width: 149, height: 21)
        
        let sec2 = UIImage(named: "section2.png")
        let sec2view = UIImageView(image: sec2!)
        sec2view.frame = CGRect(x: 229, y: 438, width: 207, height: 17)

        let theory1 = UIImage(named: "perc_info.png")
        let theoryview1 = UIImageView(image: theory1!)
        theoryview1.frame = CGRect(x: 229, y: 192, width: 237, height: 60)
        
        let theory2 = UIImage(named: "mlp_info.png")
        let theoryview2 = UIImageView(image: theory2!)
        theoryview2.frame = CGRect(x: 229, y: 487, width: 232, height: 85)
        
        view.addSubview(viewShadow)
        view.addSubview(viewShadow2)
        view.addSubview(viewShadow3)
        view.addSubview(srect1)
        view.addSubview(srect2)
        view.addSubview(view01)
        view.addSubview(view02)
        view.addSubview(sec1view)
        view.addSubview(sec2view)
        view.addSubview(theoryview1)
        view.addSubview(theoryview2)
        view.addSubview(infonextbutton)
    }
    
}
