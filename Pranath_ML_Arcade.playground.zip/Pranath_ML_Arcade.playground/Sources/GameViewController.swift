import UIKit
import PlaygroundSupport
import AVFoundation


public class GameViewController: UIViewController, AVAudioPlayerDelegate {
  
    var L1_neurons = [UIView]()
    var L1_shadows = [UIView]()
    var i:Int = 0
    var L1_x:Int = 126
    var L1_y:Int = 570
    var L1_w:Int = 39
    var L1_h:Int = 39
    
    var L2_neurons = [UIView]()
    var L2_shadows = [UIView]()
    var j:Int = 0
    var L2_x:Int = 233
    var L2_y:Int = 501
    var L2_w:Int = 39
    var L2_h:Int = 39
    
    var L3_neurons = [UIView]()
    var L3_shadows = [UIView]()
    var k:Int = 0
    var L3_x:Int = 344
    var L3_y:Int = 501
    var L3_w:Int = 39
    var L3_h:Int = 39
    
    var L4_neurons = [UIView]()
    var L4_shadows = [UIView]()
    var l:Int = 0
    var L4_x:Int = 444
    var L4_y:Int = 570
    var L4_w:Int = 39
    var L4_h:Int = 39
    
    lazy var button1: UIButton = {
        let button = UIButton()
        button.frame = CGRect(x: L1_x, y: 570, width: L1_w, height: L1_h)
        button.setImage(UIImage(named: "nbutton"), for: .normal)
        button.addTarget(self, action: #selector(tone1tap(_:)), for: .touchUpInside)
        button.tag = 1
        return button
    }()
    
    lazy var button2: UIButton = {
        let button = UIButton()
        button.frame = CGRect(x: L1_x, y: 639, width: L1_w, height: L1_h)
        button.setImage(UIImage(named: "nbutton"), for: .normal)
        button.addTarget(self, action: #selector(tone1tap(_:)), for: .touchUpInside)
        button.tag = 2
        return button
    }()
    
    lazy var button3: UIButton = {
        let button = UIButton()
        button.frame = CGRect(x: L2_x, y: 501, width: L2_w, height: L2_h)
        button.setImage(UIImage(named: "nbutton"), for: .normal)
        button.addTarget(self, action: #selector(tone2tap(_:)), for: .touchUpInside)
        button.tag = 3
        return button
    }()
    
    lazy var button4: UIButton = {
        let button = UIButton()
        button.frame = CGRect(x: L2_x, y: 570, width: L2_w, height: L2_h)
        button.setImage(UIImage(named: "nbutton"), for: .normal)
        button.addTarget(self, action: #selector(tone2tap(_:)), for: .touchUpInside)
        button.tag = 4
        return button
    }()
    
    lazy var button5: UIButton = {
        let button = UIButton()
        button.frame = CGRect(x: L2_x, y: 639, width: L2_w, height: L2_h)
        button.setImage(UIImage(named: "nbutton"), for: .normal)
        button.addTarget(self, action: #selector(tone2tap(_:)), for: .touchUpInside)
        button.tag = 5
        return button
    }()
    
    lazy var button6: UIButton = {
        let button = UIButton()
        button.frame = CGRect(x: L2_x, y: 708, width: L2_w, height: L2_h)
        button.setImage(UIImage(named: "nbutton"), for: .normal)
        button.addTarget(self, action: #selector(tone2tap(_:)), for: .touchUpInside)
        button.tag = 6
        return button
    }()
    
    lazy var button7: UIButton = {
        let button = UIButton()
        button.frame = CGRect(x: L3_x, y: 501, width: L3_w, height: L3_h)
        button.setImage(UIImage(named: "nbutton"), for: .normal)
        button.addTarget(self, action: #selector(tone3tap(_:)), for: .touchUpInside)
        button.tag = 7
        return button
    }()
    
    lazy var button8: UIButton = {
        let button = UIButton()
        button.frame = CGRect(x: L3_x, y: 570, width: L3_w, height: L3_h)
        button.setImage(UIImage(named: "nbutton"), for: .normal)
        button.addTarget(self, action: #selector(tone3tap(_:)), for: .touchUpInside)
        button.tag = 8
        return button
    }()
    
    lazy var button9: UIButton = {
        let button = UIButton()
        button.frame = CGRect(x: L3_x, y: 639, width: L3_w, height: L3_h)
        button.setImage(UIImage(named: "nbutton"), for: .normal)
        button.addTarget(self, action: #selector(tone3tap(_:)), for: .touchUpInside)
        button.tag = 9
        return button
    }()
    
    lazy var button10: UIButton = {
        let button = UIButton()
        button.frame = CGRect(x: L3_x, y: 708, width: L3_w, height: L3_h)
        button.setImage(UIImage(named: "nbutton"), for: .normal)
        button.addTarget(self, action: #selector(tone3tap(_:)), for: .touchUpInside)
        button.tag = 10
        return button
    }()
    
    lazy var button11: UIButton = {
        let button = UIButton()
        button.frame = CGRect(x: L4_x, y: 570, width: L4_w, height: L4_h)
        button.setImage(UIImage(named: "nbutton"), for: .normal)
        button.addTarget(self, action: #selector(tone4tap(_:)), for: .touchUpInside)
        button.tag = 11
        return button
    }()
    
    lazy var button12: UIButton = {
        let button = UIButton()
        button.frame = CGRect(x: L4_x, y: 639, width: L4_w, height: L4_h)
        button.setImage(UIImage(named: "nbutton"), for: .normal)
        button.addTarget(self, action: #selector(tone4tap(_:)), for: .touchUpInside)
        button.tag = 12
        return button
    }()
    
    @objc func tone1tap(_ sender: UIButton){if ready {
        tone1player.play()
        check(buttonPressed: sender)
        
        }}
    @objc func tone2tap(_ sender: UIButton){if ready {
        tone2player.play()
        check(buttonPressed: sender)
        
        }}
    @objc func tone3tap(_ sender: UIButton){if ready {
        tone3player.play()
        check(buttonPressed: sender)
        
        }}
    @objc func tone4tap(_ sender: UIButton){if ready {
        tone4player.play()
        check(buttonPressed: sender)
        
        }}
    
    var tone1player:AVAudioPlayer!
    var tone2player:AVAudioPlayer!
    var tone3player:AVAudioPlayer!
    var tone4player:AVAudioPlayer!
    
    var order = [Int]()
    var curitem = 0
    var tapcount = 0
    var playcount = 0
    var ready = false
    var orderlist = [[0,4,7,11],[1,5,6,10],[0,3,5,7,9,10],[1,2,3,8,9,11]]
    func audiosetup(){
    
        let soundfilepath1 = Bundle.main.path(forResource: "tone1",ofType: "wav")
        let soundfileURL1 = NSURL(fileURLWithPath: soundfilepath1!)
        let soundfilepath2 = Bundle.main.path(forResource: "tone2",ofType: "wav")
        let soundfileURL2 = NSURL(fileURLWithPath: soundfilepath2!)
        let soundfilepath3 = Bundle.main.path(forResource: "tone3",ofType: "wav")
        let soundfileURL3 = NSURL(fileURLWithPath: soundfilepath3!)
        let soundfilepath4 = Bundle.main.path(forResource: "tone4",ofType: "wav")
        let soundfileURL4 = NSURL(fileURLWithPath: soundfilepath4!)
    
        do{
        try tone1player = AVAudioPlayer(contentsOf: soundfileURL1 as URL)
        try tone2player = AVAudioPlayer(contentsOf: soundfileURL2 as URL)
        try tone3player = AVAudioPlayer(contentsOf: soundfileURL3 as URL)
        try tone4player = AVAudioPlayer(contentsOf: soundfileURL4 as URL)
        }catch{print("audio error")}
    
        tone1player.delegate = self
        tone2player.delegate = self
        tone3player.delegate = self
        tone4player.delegate = self
        tone1player.numberOfLoops = 0
        tone2player.numberOfLoops = 0
        tone3player.numberOfLoops = 0
        tone4player.numberOfLoops = 0
    }
    
    lazy var buttons = [button1,button2,button3,button4,button5,button6,button7,button8,button9,button10,button11,button12]
    
    
    lazy var sbutton: UIButton = {
        let sbutton = UIButton()
        sbutton.frame = CGRect(x: 270, y: 364, width: 72, height: 72)
        sbutton.setImage(UIImage(named: "speaker_button"), for: .normal)
        sbutton.addTarget(self, action: #selector(speakertap(_:)), for: .touchUpInside)
        view.addSubview(sbutton)
        return sbutton
    }()
    
    lazy var speaker_shadow: UIView = {
        let speaker_shadow = UIView()
        speaker_shadow.frame = CGRect(x: 270, y: 364, width: 72, height: 72)
        speaker_shadow.center = sbutton.center
        speaker_shadow.backgroundColor = UIColor.white
        speaker_shadow.layer.cornerRadius = 72/2
        speaker_shadow.layer.shadowColor = UIColor.darkGray.cgColor
        speaker_shadow.layer.shadowOpacity = 0.5
        speaker_shadow.layer.shadowOffset = CGSize.zero
        speaker_shadow.layer.shadowRadius = 20
        return speaker_shadow
    }()
    
    lazy var nextbutton: UIButton = {
        let nextbutton = UIButton()
        nextbutton.frame = CGRect(x: 224, y: 375, width: 152, height: 51)
        nextbutton.setImage(UIImage(named: "next_1"), for: .normal)
        nextbutton.addTarget(self, action: #selector(nexttap(_:)), for: .touchUpInside)
        view.addSubview(nextbutton)
        return nextbutton
    }()
    
    lazy var next_shadow: UIView = {
        let next_shadow = UIView()
        next_shadow.frame = CGRect(x: 224, y: 375, width: 152, height: 51)
        next_shadow.center = nextbutton.center
        next_shadow.backgroundColor = UIColor.white
        next_shadow.layer.cornerRadius = 15
        next_shadow.layer.shadowColor = UIColor.darkGray.cgColor
        next_shadow.layer.shadowOpacity = 0.5
        next_shadow.layer.shadowOffset = CGSize.zero
        next_shadow.layer.shadowRadius = 20
        return next_shadow
    }()
    
    lazy var point1: UILabel = {
        let point1 = UILabel()
        point1.frame = CGRect(x: 222, y: 147, width: 22, height: 22)
        point1.clipsToBounds = true
        point1.layer.cornerRadius = 22/2
        point1.backgroundColor = UIColor(red: 1.00, green: 0.51, blue: 0.51, alpha: 1)
        point1.alpha = 1
        return point1
    }()
    
    lazy var point2: UILabel = {
        let point2 = UILabel()
        point2.frame = CGRect(x: 274, y: 162, width: 22, height: 22)
        point2.clipsToBounds = true
        point2.layer.cornerRadius = 22/2
        point2.backgroundColor = UIColor(red: 0.97, green: 0.78, blue: 0.47, alpha: 1)
        point2.alpha = 1
        return point2
    }()

    lazy var point3: UILabel = {
        let point3 = UILabel()
        point3.frame = CGRect(x: 305, y: 219, width: 22, height: 22)
        point3.clipsToBounds = true
        point3.layer.cornerRadius = 22/2
        point3.backgroundColor = UIColor(red: 0.95, green: 0.95, blue: 0.52, alpha: 1)
        point3.alpha = 1
        return point3
    }()
    
    lazy var point4: UILabel = {
        let point4 = UILabel()
        point4.frame = CGRect(x: 361, y: 240, width: 22, height: 22)
        point4.clipsToBounds = true
        point4.layer.cornerRadius = 22/2
        point4.backgroundColor = UIColor(red: 0.45, green: 0.93, blue: 0.70, alpha: 1)
        point4.alpha = 1
        return point4
    }()
    
    lazy var wrong_view: UIImageView = {
        let wrong_icon = UIImage(named: "wrong_button.png")
        let wrong_view = UIImageView(image: wrong_icon!)
        wrong_view.frame = CGRect(x: 270, y: 364, width: 72, height: 72)
        return wrong_view
    }()
    
    lazy var right_view: UIImageView = {
        let right_icon = UIImage(named: "right_button.png")
        let right_view = UIImageView(image: right_icon!)
        right_view.frame = CGRect(x: 270, y: 364, width: 72, height: 72)
        return right_view
    }()
    
    lazy var points = [point1,point2,point3,point4]
    
    func check (buttonPressed: UIButton) {
        if buttonPressed == buttons[order[tapcount]] {
            if tapcount == order.count - 1 {
                let timer = DispatchTime.now() + DispatchTimeInterval.seconds(Int(1.0))
                DispatchQueue.main.asyncAfter(deadline: timer){

                    self.nextround()

                }
                
                return
                
            }
            tapcount += 1
        }else{reset()}}
    
    func reset() {
        ready = false
        tapcount = 0
        curitem = 0
        view.addSubview(wrong_view)
        disablebuttons()
    }
    
    func nextround() {
        
        if (playcount < 3 ){
            view.addSubview(points[playcount])
            view.addSubview(right_view)
            playcount += 1
            ready = false
            tapcount = 0
            curitem = 0
            disablebuttons()
            order = orderlist[playcount]
            playnext()}
        else{
            view.addSubview(right_view)
            view.addSubview(points[3])
            sleep(1)
            disablebuttons()
            right_view.isHidden = true
            wrong_view.isHidden = true
            sbutton.isHidden = true
            speaker_shadow.isHidden = true
            next_shadow.isHidden = false
            nextbutton.isHidden = false
        }
    }
    
    @objc func speakertap(_ sender: UIButton){
        disablebuttons()
        order = orderlist[playcount]
        sbutton.isHidden = true
        playnext()}
    
    @objc func nexttap(_ sender: UIButton){
        let nextview = ThankViewController()
        navigationController?.pushViewController(nextview, animated: true)
    }
    
    public func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        
        if curitem <= order.count - 1 {
            playnext()
        }
        else{
            ready = true
            resetbuttons()
            enablebuttons()
        }
    }
    
    
    @IBAction func playnext () {
        
        let selection = order[curitem]
        
        switch selection {
        case 0,1:
            resetbuttons ()
            tone1player.play()
            buttons[selection].setImage(UIImage(named: "nbutton2"), for: .normal)
            break
        case 2,3,4,5:
            resetbuttons ()
            tone2player.play()
            buttons[selection].setImage(UIImage(named: "nbutton2"), for: .normal)
            break
        case 6,7,8,9:
            resetbuttons ()
            tone3player.play()
            buttons[selection].setImage(UIImage(named: "nbutton2"), for: .normal)
            break
        case 10,11:
            resetbuttons ()
            tone4player.play()
            buttons[selection].setImage(UIImage(named: "nbutton2"), for: .normal)
            break
        default:
            break;
        }
        
        curitem += 1
        
    }
    
    func resetbuttons () {
        for button in buttons {
            button.setImage(UIImage(named: "nbutton"), for: .normal)
        }
    }
    
    func disablebuttons () {
        for button in buttons {
            button.isUserInteractionEnabled = false
        }
    }
    
    func enablebuttons () {
        for button in buttons {
            button.isUserInteractionEnabled = true
        }
    }
    
    public override func viewDidLoad() {
        
        super.viewDidLoad()
        let view = UIView(frame: CGRect(x: 0, y: 0, width: 600, height: 800))
        view.backgroundColor = .white
        let viewgradient = CAGradientLayer()
        viewgradient.frame = view.bounds
        viewgradient.colors = [UIColor(red: 0.56, green: 0.83, blue: 0.96, alpha: 1).cgColor, UIColor(red: 1.00, green: 1.00, blue: 1.00, alpha: 1).cgColor]
        viewgradient.transform = CATransform3DMakeRotation(CGFloat.pi, 0, 0, 1)
        view.layer.addSublayer(viewgradient)
        self.view = view
        navigationController?.isNavigationBarHidden = true
        
        audiosetup()
        
        let connections = UIImage(named: "connections.png")
        let connec_view = UIImageView(image: connections!)
        connec_view.frame = CGRect(x: 143, y: 510, width: 329, height: 216)
        view.addSubview(connec_view)

        while i < 2{
            L1_neurons.append(UIView(frame: CGRect(x: L1_x, y: L1_y, width: L1_w, height: L1_h)))
            L1_neurons[i].clipsToBounds = true
            L1_neurons[i].backgroundColor = UIColor(red: 0.88, green: 0.88, blue: 0.88, alpha: 1)
            L1_neurons[i].layer.cornerRadius = 39/2
            L1_neurons[i].alpha = 1
    
            L1_shadows.append(UIView(frame: CGRect(x: L1_x, y: L1_y, width: L1_w, height: L1_h)))
            L1_shadows[i].center = L1_neurons[i].center
            L1_shadows[i].backgroundColor = UIColor.black
            L1_shadows[i].layer.cornerRadius = 39/2
            L1_shadows[i].layer.shadowColor = UIColor.darkGray.cgColor
            L1_shadows[i].layer.shadowOpacity = 0.5
            L1_shadows[i].layer.shadowOffset = CGSize.zero
            L1_shadows[i].layer.shadowRadius = 20
            view.addSubview(L1_shadows[i])
            view.addSubview(L1_neurons[i])
    
            i = i + 1
            L1_y = L1_y + 69
        }

        while j < 4{
            L2_neurons.append(UIView(frame: CGRect(x: L2_x, y: L2_y, width: L2_w, height: L2_h)))
            L2_neurons[j].clipsToBounds = true
            L2_neurons[j].backgroundColor = UIColor(red: 0.88, green: 0.88, blue: 0.88, alpha: 1)
            L2_neurons[j].layer.cornerRadius = 39/2
            L2_neurons[j].alpha = 1
    
            L2_shadows.append(UIView(frame: CGRect(x: L2_x, y: L2_y, width: L2_w, height: L2_h)))
            L2_shadows[j].center = L2_neurons[j].center
            L2_shadows[j].backgroundColor = UIColor.black
            L2_shadows[j].layer.cornerRadius = 39/2
            L2_shadows[j].layer.shadowColor = UIColor.darkGray.cgColor
            L2_shadows[j].layer.shadowOpacity = 0.5
            L2_shadows[j].layer.shadowOffset = CGSize.zero
            L2_shadows[j].layer.shadowRadius = 20
            view.addSubview(L2_shadows[j])
            view.addSubview(L2_neurons[j])
    
            j = j + 1
            L2_y = L2_y + 69
        }

        while k < 4{
            L3_neurons.append(UIView(frame: CGRect(x: L3_x, y: L3_y, width: L3_w, height: L3_h)))
            L3_neurons[k].clipsToBounds = true
            L3_neurons[k].backgroundColor = UIColor(red: 0.88, green: 0.88, blue: 0.88, alpha: 1)
            L3_neurons[k].layer.cornerRadius = 39/2
            L3_neurons[k].alpha = 1
    
            L3_shadows.append(UIView(frame: CGRect(x: L3_x, y: L3_y, width: L3_w, height: L3_h)))
            L3_shadows[k].center = L3_neurons[k].center
            L3_shadows[k].backgroundColor = UIColor.black
            L3_shadows[k].layer.cornerRadius = 39/2
            L3_shadows[k].layer.shadowColor = UIColor.darkGray.cgColor
            L3_shadows[k].layer.shadowOpacity = 0.5
            L3_shadows[k].layer.shadowOffset = CGSize.zero
            L3_shadows[k].layer.shadowRadius = 20
            view.addSubview(L3_shadows[k])
            view.addSubview(L3_neurons[k])
    
            k = k + 1
            L3_y = L3_y + 69
        }

        while l < 2{
            L4_neurons.append(UIView(frame: CGRect(x: L4_x, y: L4_y, width: L4_w, height: L4_h)))
            L4_neurons[l].clipsToBounds = true
            L4_neurons[l].backgroundColor = UIColor(red: 0.88, green: 0.88, blue: 0.88, alpha: 1)
            L4_neurons[l].layer.cornerRadius = 39/2
            L4_neurons[l].alpha = 1
    
            L4_shadows.append(UIView(frame: CGRect(x: L4_x, y: L4_y, width: L4_w, height: L4_h)))
            L4_shadows[l].center = L4_neurons[l].center
            L4_shadows[l].backgroundColor = UIColor.black
            L4_shadows[l].layer.cornerRadius = 39/2
            L4_shadows[l].layer.shadowColor = UIColor.darkGray.cgColor
            L4_shadows[l].layer.shadowOpacity = 0.5
            L4_shadows[l].layer.shadowOffset = CGSize.zero
            L4_shadows[l].layer.shadowRadius = 20
            view.addSubview(L4_shadows[l])
            view.addSubview(L4_neurons[l])
    
            l = l + 1
            L4_y = L4_y + 69
        }
        
        view.addSubview(button1)
        view.addSubview(button2)
        view.addSubview(button3)
        view.addSubview(button4)
        view.addSubview(button5)
        view.addSubview(button6)
        view.addSubview(button7)
        view.addSubview(button8)
        view.addSubview(button9)
        view.addSubview(button10)
        view.addSubview(button12)
        view.addSubview(button11)
        
        view.addSubview(speaker_shadow)
        view.addSubview(sbutton)
        
        let graph = UIView(frame: CGRect(x: 210, y: 91, width: 181, height: 200))
        graph.clipsToBounds = true
        graph.backgroundColor = UIColor.white
        graph.layer.cornerRadius = 10
        graph.alpha = 1

        let graph_shadow = UIView(frame: CGRect(x: 210, y: 91, width: 181, height: 200))
        graph_shadow.center = graph.center
        graph_shadow.backgroundColor = UIColor.white
        graph_shadow.layer.cornerRadius = 10
        graph_shadow.layer.shadowColor = UIColor.darkGray.cgColor
        graph_shadow.layer.shadowOpacity = 0.5
        graph_shadow.layer.shadowOffset = CGSize.zero
        graph_shadow.layer.shadowRadius = 20
        view.addSubview(graph_shadow)
        view.addSubview(graph)

        let graph_title = UIImage(named: "cost.png")
        let grapht_view = UIImageView(image: graph_title!)
        grapht_view.frame = CGRect(x: 275, y: 105, width: 53, height: 19)
        view.addSubview(grapht_view)

        let curve = UIImage(named: "curve.png")
        let curve_view = UIImageView(image: curve!)
        curve_view.frame = CGRect(x: 230, y: 154, width: 141, height: 98)
        view.addSubview(curve_view)
        
        view.addSubview(next_shadow)
        view.addSubview(nextbutton)
        
        nextbutton.isHidden = true
        next_shadow.isHidden = true
        
    }
    
}
