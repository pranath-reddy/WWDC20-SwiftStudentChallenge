import UIKit
import PlaygroundSupport

public class TutViewController: UIViewController {
    
    public lazy var playbutton: UIButton = {
        let playbutton = UIButton()
        playbutton.frame = CGRect(x: 237, y: 700, width: 134, height: 41)
        playbutton.setImage(UIImage(named: "play"), for: .normal)
        playbutton.addTarget(self, action: #selector(playbuttontapped(_:)), for: .touchUpInside)
        return playbutton
    }()
    
    @objc func playbuttontapped(_ sender: UIButton){
        let nextview = GameViewController()
        navigationController?.pushViewController(nextview, animated: true)
    }
    
    public override func viewDidLoad() {
        
        super.viewDidLoad()
        let view = UIView(frame: CGRect(x: 0, y: 0, width: 600, height: 800))
        view.backgroundColor = .white
        self.view = view
        navigationController?.isNavigationBarHidden = true

        let lrect = UILabel(frame: CGRect(x: 0, y: 0, width: 300, height: 800))
        lrect.clipsToBounds = true
        let lrectgradient = CAGradientLayer()
        lrectgradient.frame = lrect.bounds
        lrectgradient.colors = [UIColor(red: 0.56, green: 0.83, blue: 0.96, alpha: 1).cgColor, UIColor(red: 1.00, green: 1.00, blue: 1.00, alpha: 1).cgColor]
        lrectgradient.transform = CATransform3DMakeRotation(CGFloat.pi, 0, 0, 1)
        lrect.layer.addSublayer(lrectgradient)
        lrect.alpha = 1

        view.addSubview(lrect)

        let speaker = UILabel(frame: CGRect(x: 119, y: 167, width: 63, height: 63))
        speaker.clipsToBounds = true
        speaker.layer.cornerRadius = 63/2
        speaker.backgroundColor = UIColor(red: 1.00, green: 1.00, blue: 1.00, alpha: 1)
        speaker.alpha = 1

        let playrect = UILabel(frame: CGRect(x: 237, y: 700, width: 134, height: 41))
        playrect.clipsToBounds = true
        playrect.layer.cornerRadius = 10
        playrect.backgroundColor = UIColor(red: 1.00, green: 1.00, blue: 1.00, alpha: 1)
        playrect.alpha = 1

        let graphrect = UILabel(frame: CGRect(x: 75, y: 473, width: 151, height: 167))
        graphrect.clipsToBounds = true
        graphrect.layer.cornerRadius = 10
        graphrect.backgroundColor = UIColor(red: 1.00, green: 1.00, blue: 1.00, alpha: 1)
        graphrect.alpha = 1

        let playShadow = UIView(frame: CGRect(x: 237, y: 700, width: 134, height: 41))
        playShadow.center = playrect.center
        playShadow.backgroundColor = UIColor.black
        playShadow.layer.cornerRadius = 10
        playShadow.layer.shadowColor = UIColor.darkGray.cgColor
        playShadow.layer.shadowOpacity = 0.5
        playShadow.layer.shadowOffset = CGSize.zero
        playShadow.layer.shadowRadius = 20
        view.addSubview(playShadow)

        let gShadow = UIView(frame: CGRect(x: 75, y: 473, width: 151, height: 167))
        gShadow.center = graphrect.center
        gShadow.backgroundColor = UIColor.black
        gShadow.layer.cornerRadius = 10
        gShadow.layer.shadowColor = UIColor.darkGray.cgColor
        gShadow.layer.shadowOpacity = 0.35
        gShadow.layer.shadowOffset = CGSize.zero
        gShadow.layer.shadowRadius = 20
        view.addSubview(gShadow)

        let sShadow = UIView(frame: CGRect(x: 119, y: 167, width: 63, height: 63))
        sShadow.center = speaker.center
        sShadow.backgroundColor = UIColor.black
        sShadow.layer.cornerRadius = 63/2
        sShadow.layer.shadowColor = UIColor.darkGray.cgColor
        sShadow.layer.shadowOpacity = 0.35
        sShadow.layer.shadowOffset = CGSize.zero
        sShadow.layer.shadowRadius = 20
        view.addSubview(sShadow)

        let graph = UIImage(named: "cost.png")
        let graphview = UIImageView(image: graph!)
        graphview.frame = CGRect(x: 129, y: 485, width: 44, height: 16)

        let neurons = UIImage(named: "neurons_tut.png")
        let neuronview = UIImageView(image: neurons!)
        neuronview.frame = CGRect(x: 60, y: 264, width: 173, height: 175)

        let title = UIImage(named: "Tut_title.png")
        let titleview = UIImageView(image: title!)
        titleview.frame = CGRect(x: 226, y: 53, width: 149, height: 31)

        let sp_img = UIImage(named: "speaker_button.png")
        let speakerview = UIImageView(image: sp_img!)
        speakerview.frame = CGRect(x: 119, y: 167, width: 63, height: 63)

        let plot = UIImage(named: "plot.png")
        let plotview = UIImageView(image: plot!)
        plotview.frame = CGRect(x: 91, y: 527, width: 119, height: 85)

        let string1 = UIImage(named: "instr1.png")
        let string1view = UIImageView(image: string1!)
        string1view.frame = CGRect(x: 314, y: 153, width: 256, height: 94)
        
        let string2 = UIImage(named: "instr2.png")
        let string2view = UIImageView(image: string2!)
        string2view.frame = CGRect(x: 314, y: 290, width: 236, height: 112)
        
        let string3 = UIImage(named: "instr3.png")
        let string3view = UIImageView(image: string3!)
        string3view.frame = CGRect(x: 314, y: 471, width: 256, height: 173)

        view.addSubview(playrect)
        view.addSubview(graphrect)
        view.addSubview(graphview)
        view.addSubview(neuronview)
        view.addSubview(playbutton)
        view.addSubview(titleview)
        view.addSubview(speaker)
        view.addSubview(speakerview)
        view.addSubview(plotview)
        view.addSubview(string1view)
        view.addSubview(string2view)
        view.addSubview(string3view)
    }
}
