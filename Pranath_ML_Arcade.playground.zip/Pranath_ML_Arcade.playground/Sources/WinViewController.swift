import UIKit
import PlaygroundSupport

public class WinViewController: UIViewController {
    
    public lazy var winnextbutton: UIButton = {
        let winnextbutton = UIButton()
        winnextbutton.frame = CGRect(x: 224, y: 503, width: 152, height: 54)
        winnextbutton.setImage(UIImage(named: "next_button"), for: .normal)
        winnextbutton.addTarget(self, action: #selector(wnextbuttontapped(_:)), for: .touchUpInside)
        return winnextbutton
    }()
    
    
    @objc func wnextbuttontapped(_ sender: UIButton){
        let nextview = PredViewController()
        navigationController?.pushViewController(nextview, animated: true)
    }
    
    
    public override func viewDidLoad() {
        
        super.viewDidLoad()
        let view = UIView(frame: CGRect(x: 0, y: 0, width: 600, height: 800))
        view.backgroundColor = .white
        view.alpha = 1
        self.view = view
        navigationController?.isNavigationBarHidden = true
        
        let buttonrect = UIView()
        buttonrect.frame = CGRect(x: 224, y: 503, width: 152, height: 54)
        buttonrect.clipsToBounds = true
        buttonrect.layer.cornerRadius = 15
        buttonrect.backgroundColor = UIColor(red: 1.00, green: 1.00, blue: 1.00, alpha: 1)
        buttonrect.alpha = 1
        
        let viewShadow = UIView(frame: CGRect(x: 224, y: 503, width: 152, height: 54))
        viewShadow.center = buttonrect.center
        viewShadow.backgroundColor = UIColor.black
        viewShadow.layer.cornerRadius = 15
        viewShadow.layer.shadowColor = UIColor.darkGray.cgColor
        viewShadow.layer.shadowOpacity = 0.3
        viewShadow.layer.shadowOffset = CGSize.zero
        viewShadow.layer.shadowRadius = 20
    
        let arc = UIImage(named: "arc3.png")
        let arcview = UIImageView(image: arc!)
        arcview.frame = CGRect(x: 0, y: 209, width: 591, height: 591)
        view.addSubview(arcview)
        
        let message = UIImage(named: "win_message_2.png")
        let messview = UIImageView(image: message!)
        messview.frame = CGRect(x: 154, y: 389, width: 293, height: 76)
        
        let done = UIImage(named: "done.png")
        let doneview = UIImageView(image: done!)
        doneview.frame = CGRect(x: 208, y: 139, width: 184, height: 184)
        
        view.addSubview(viewShadow)
        view.addSubview(buttonrect)
        view.addSubview(messview)
        view.addSubview(doneview)
        view.addSubview(winnextbutton)
    }
    
}
