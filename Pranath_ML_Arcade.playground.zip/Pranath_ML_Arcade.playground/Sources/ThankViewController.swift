import UIKit
import PlaygroundSupport

public class ThankViewController: UIViewController {
    
    public lazy var aboutbutton: UIButton = {
        let aboutbutton = UIButton()
        aboutbutton.frame = CGRect(x: 227, y: 673, width: 147, height: 50)
        aboutbutton.setImage(UIImage(named: "replay_button"), for: .normal)
        aboutbutton.addTarget(self, action: #selector(aboutbuttontapped(_:)), for: .touchUpInside)
        return aboutbutton
    }()
    
    @objc func aboutbuttontapped(_ sender: UIButton){
        let nextview = IntroViewController()
        navigationController?.pushViewController(nextview, animated: true)
    }
    
    public override func viewDidLoad() {
        
        super.viewDidLoad()
        let view = UIView(frame: CGRect(x: 0, y: 0, width: 600, height: 800))
        view.backgroundColor = .white
        view.alpha = 1
        self.view = view
        navigationController?.isNavigationBarHidden = true
        
        let buttonrect = UIView()
        buttonrect.frame = CGRect(x: 227, y: 673, width: 147, height: 50)
        buttonrect.clipsToBounds = true
        buttonrect.layer.cornerRadius = 15
        buttonrect.backgroundColor = UIColor(red: 1.00, green: 1.00, blue: 1.00, alpha: 1)
        buttonrect.alpha = 1
        
        let viewShadow = UIView(frame: CGRect(x: 227, y: 673, width: 147, height: 50))
        viewShadow.center = buttonrect.center
        viewShadow.backgroundColor = UIColor.black
        viewShadow.layer.cornerRadius = 15
        viewShadow.layer.shadowColor = UIColor.darkGray.cgColor
        viewShadow.layer.shadowOpacity = 0.5
        viewShadow.layer.shadowOffset = CGSize.zero
        viewShadow.layer.shadowRadius = 20
        
        let viewShadow2 = UIView(frame: CGRect(x: 94, y: 305, width: 412, height: 454))
        viewShadow2.backgroundColor = UIColor.white
        viewShadow2.layer.cornerRadius = 20
        viewShadow2.layer.shadowColor = UIColor.darkGray.cgColor
        viewShadow2.layer.shadowOpacity = 0.5
        viewShadow2.layer.shadowOffset = CGSize.zero
        viewShadow2.layer.shadowRadius = 20
        
        let arc = UIImage(named: "arc2.png")
        let arcview = UIImageView(image: arc!)
        arcview.frame = CGRect(x: 1, y: 0, width: 500, height: 500)
        view.addSubview(arcview)
        
        let message = UIImage(named: "message.png")
        let messview = UIImageView(image: message!)
        messview.frame = CGRect(x: 141, y: 461, width: 317, height: 104)
        
        let logo = UIImage(named: "swift_logo.png")
        let logoview = UIImageView(image: logo!)
        logoview.frame = CGRect(x: 300, y: 165, width: 110, height: 99)
        view.addSubview(logoview)
        
        let logo2 = UIImage(named: "wwdc_logo.png")
        let logoview2 = UIImageView(image: logo2!)
        logoview2.frame = CGRect(x: 190, y: 172, width: 95, height: 87)
        view.addSubview(logoview2)
        
        let thankyou = UIImage(named: "thank_you.png")
        let THview = UIImageView(image: thankyou!)
        THview.frame = CGRect(x: 215, y: 361, width: 171, height: 30)
        
        view.addSubview(viewShadow2)
        view.addSubview(viewShadow)
        view.addSubview(buttonrect)
        view.addSubview(messview)
        view.addSubview(THview)
        view.addSubview(aboutbutton)
    }
    
}
