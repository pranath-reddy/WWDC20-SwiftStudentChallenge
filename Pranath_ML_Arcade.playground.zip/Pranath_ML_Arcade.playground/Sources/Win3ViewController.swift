import UIKit
import PlaygroundSupport

class Win3ViewController: UIViewController {
    
    public lazy var win3nextbutton: UIButton = {
        let win3nextbutton = UIButton()
        win3nextbutton.frame = CGRect(x: 237, y: 681, width: 127, height: 46)
        win3nextbutton.setImage(UIImage(named: "info_button"), for: .normal)
        win3nextbutton.addTarget(self, action: #selector(win3nextbuttontapped(_:)), for: .touchUpInside)
        return win3nextbutton
    }()
    
    @objc func win3nextbuttontapped(_ sender: UIButton){
        let nextview = Pred3ViewController()
        navigationController?.pushViewController(nextview, animated: true)
    }
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        let view = UIView(frame: CGRect(x: 0, y: 0, width: 600, height: 800))
        view.backgroundColor = .white
        view.alpha = 1
        self.view = view
        navigationController?.isNavigationBarHidden = true

        let viewShadow8 = UIView(frame: CGRect(x: 237, y: 681, width: 127, height: 46))
        viewShadow8.backgroundColor = UIColor.white
        viewShadow8.layer.cornerRadius = 15
        viewShadow8.layer.shadowColor = UIColor.darkGray.cgColor
        viewShadow8.layer.shadowOpacity = 0.35
        viewShadow8.layer.shadowOffset = CGSize.zero
        viewShadow8.layer.shadowRadius = 20
 
        let title = UIImage(named: "win3_title.png")
        let titleview = UIImageView(image: title!)
        titleview.frame = CGRect(x: 155, y: 202, width: 291, height: 133)
        view.addSubview(titleview)
        
        let arc = UIImage(named: "arc_win2.png")
        let arcview = UIImageView(image: arc!)
        arcview.frame = CGRect(x: 0, y: -159, width: 958, height: 958)
        view.addSubview(arcview)
        
        view.addSubview(viewShadow8)
        view.addSubview(win3nextbutton)
    }
    
}
