import UIKit
import PlaygroundSupport

public class QuoteViewController: UIViewController {
    
    public lazy var nextbutton2: UIButton = {
        let nextbutton2 = UIButton()
        nextbutton2.frame = CGRect(x: 267, y: 667, width: 67, height: 67)
        nextbutton2.setImage(UIImage(named: "button"), for: .normal)
        nextbutton2.addTarget(self, action: #selector(nextbuttontapped2(_:)), for: .touchUpInside)
        return nextbutton2
    }()
    
    @objc func nextbuttontapped2(_ sender: UIButton){
        let nextview = ArcViewController()
        navigationController?.pushViewController(nextview, animated: true)
    }
    
    public override func viewDidLoad() {
        
        super.viewDidLoad()
        let view = UIView(frame: CGRect(x: 0, y: 0, width: 600, height: 800))
        view.backgroundColor = .white
        view.alpha = 1
        self.view = view
        navigationController?.isNavigationBarHidden = true

        let circle = UIView()
        circle.frame = CGRect(x: 267, y: 667, width: 67, height: 67)
        circle.clipsToBounds = true
        circle.layer.cornerRadius = 67/2
        circle.backgroundColor = UIColor(red: 1.00, green: 1.00, blue: 1.00, alpha: 1)
        circle.alpha = 1

        let viewShadow = UIView(frame: CGRect(x: 267, y: 667, width: 67, height: 67))
        viewShadow.center = circle.center
        viewShadow.backgroundColor = UIColor.black
        viewShadow.layer.cornerRadius = 67/2
        viewShadow.layer.shadowColor = UIColor.darkGray.cgColor
        viewShadow.layer.shadowOpacity = 0.5
        viewShadow.layer.shadowOffset = CGSize.zero
        viewShadow.layer.shadowRadius = 20

        let viewShadow2 = UIView(frame: CGRect(x: 146, y: 122, width: 308, height: 186))
        viewShadow2.backgroundColor = UIColor.white
        viewShadow2.layer.cornerRadius = 20
        viewShadow2.layer.shadowColor = UIColor.darkGray.cgColor
        viewShadow2.layer.shadowOpacity = 0.3
        viewShadow2.layer.shadowOffset = CGSize.zero
        viewShadow2.layer.shadowRadius = 20

        let viewShadow3 = UIView(frame: CGRect(x: 146, y: 362, width: 308, height: 218))
        viewShadow3.backgroundColor = UIColor.white
        viewShadow3.layer.cornerRadius = 20
        viewShadow3.layer.shadowColor = UIColor.darkGray.cgColor
        viewShadow3.layer.shadowOpacity = 0.3
        viewShadow3.layer.shadowOffset = CGSize.zero
        viewShadow3.layer.shadowRadius = 20

        let arc = UIImage(named: "Arc.png")
        let arcview = UIImageView(image: arc!)
        view.addSubview(arcview)

        let quote1 = UIImage(named: "tim_quote.png")
        let qview1 = UIImageView(image: quote1!)
        qview1.frame = CGRect(x: 161, y: 173, width: 260, height: 78)
        qview1.center = viewShadow2.center

        let quote2 = UIImage(named: "andrew_quote.png")
        let qview2 = UIImageView(image: quote2!)
        qview2.frame = CGRect(x: 161, y: 400, width: 260, height: 133)
        qview2.center = viewShadow3.center

        view.addSubview(viewShadow)
        view.addSubview(viewShadow2)
        view.addSubview(viewShadow3)
        view.addSubview(qview1)
        view.addSubview(qview2)
        view.addSubview(circle)
        view.addSubview(nextbutton2)
    }
    
}
