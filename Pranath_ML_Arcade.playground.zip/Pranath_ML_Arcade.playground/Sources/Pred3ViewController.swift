import UIKit
import PlaygroundSupport
import Vision

import CoreML

public class Pred3ViewController: UIViewController {
    
    let model = g_AB()
    let model2 = g_BA()
        
    let test1  = UIImage(named: "yosemite.jpg")
    let test2  = UIImage(named: "capitan.jpg")
    let test3  = UIImage(named: "sierra.jpg")
    let test4  = UIImage(named: "hsierra.jpg")
    let test5  = UIImage(named: "testA.jpg")
    let test6  = UIImage(named: "testB.jpg")
    let test7  = UIImage(named: "testC.jpg")
    
    let viewShadow5 = UIView(frame: CGRect(x: 96, y: 104, width: 408, height: 517))
    
    public lazy var blurbgview : UIImageView = {
        let blurbg = UIImage(named: "blur_bg_2.png")
        let blurbgview = UIImageView(image: blurbg!)
        blurbgview.frame = CGRect(x: 0, y: 0, width: 600, height: 800)
        return blurbgview
    }()
    
    public lazy var picselectview : UIImageView = {
        let picselect = UIImage(named: "pred3_picselect.png")
        let picselectview = UIImageView(image: picselect!)
        picselectview.frame = CGRect(x: 195, y: 136, width: 193, height: 13)
        return picselectview
    }()
    
    public lazy var summerview : UIImageView = {
        let summer = UIImage(named: "Summer Text.png")
        let summerview = UIImageView(image: summer!)
        summerview.frame = CGRect(x: 352, y: 193, width: 140, height: 40)
        return summerview
    }()
    
    public lazy var winterview : UIImageView = {
        let winter = UIImage(named: "Winter Text.png")
        let winterview = UIImageView(image: winter!)
        winterview.frame = CGRect(x: 107, y: 193, width: 140, height: 40)
        return winterview
    }()
    
    public lazy var cambutton: UIButton = {
        let cambutton = UIButton()
        cambutton.frame = CGRect(x: 222, y: 332, width: 159, height: 45)
        cambutton.setImage(UIImage(named: "pred2_select_photo"), for: .normal)
        cambutton.addTarget(self, action: #selector(cambuttontapped(_:)), for: .touchUpInside)
        return cambutton
    }()
    
    public lazy var yosemitebutton: UIButton = {
        let yosemitebutton = UIButton()
        yosemitebutton.frame = CGRect(x: 305, y: 177, width: 145, height: 145)
        yosemitebutton.setImage(UIImage(named: "yosemite.jpg"), for: .normal)
        yosemitebutton.addTarget(self, action: #selector(yosemitebuttontapped(_:)), for: .touchUpInside)
        return yosemitebutton
    }()
    
    public lazy var capitanbutton: UIButton = {
        let capitanbutton = UIButton()
        capitanbutton.frame = CGRect(x: 146, y: 177, width: 145, height: 145)
        capitanbutton.setImage(UIImage(named: "capitan.jpg"), for: .normal)
        capitanbutton.addTarget(self, action: #selector(capitanbuttontapped(_:)), for: .touchUpInside)
        return capitanbutton
    }()
    
    public lazy var sierrabutton: UIButton = {
        let sierrabutton = UIButton()
        sierrabutton.frame = CGRect(x: 146, y: 448, width: 145, height: 145)
        sierrabutton.setImage(UIImage(named: "sierra.jpg"), for: .normal)
        sierrabutton.addTarget(self, action: #selector(sierrabuttontapped(_:)), for: .touchUpInside)
        return sierrabutton
    }()
    
    public lazy var hsierrabutton: UIButton = {
        let hsierrabutton = UIButton()
        hsierrabutton.frame = CGRect(x: 305, y: 448, width: 145, height: 145)
        hsierrabutton.setImage(UIImage(named: "hsierra.jpg"), for: .normal)
        hsierrabutton.addTarget(self, action: #selector(hsierrabuttontapped(_:)), for: .touchUpInside)
        return hsierrabutton
    }()
    
    public lazy var testAbutton: UIButton = {
        let testAbutton = UIButton()
        testAbutton.frame = CGRect(x: 133, y: 333, width: 104, height: 104)
        testAbutton.setImage(UIImage(named: "testA.jpg"), for: .normal)
        testAbutton.addTarget(self, action: #selector(testAbuttontapped(_:)), for: .touchUpInside)
        return testAbutton
    }()
    
    public lazy var testBbutton: UIButton = {
        let testBbutton = UIButton()
        testBbutton.frame = CGRect(x: 246, y: 333, width: 104, height: 104)
        testBbutton.setImage(UIImage(named: "testB.jpg"), for: .normal)
        testBbutton.addTarget(self, action: #selector(testBbuttontapped(_:)), for: .touchUpInside)
        return testBbutton
    }()
    
    public lazy var testCbutton: UIButton = {
        let testCbutton = UIButton()
        testCbutton.frame = CGRect(x: 362, y: 333, width: 104, height: 104)
        testCbutton.setImage(UIImage(named: "testC.jpg"), for: .normal)
        testCbutton.addTarget(self, action: #selector(testCbuttontapped(_:)), for: .touchUpInside)
        return testCbutton
    }()
    
    public lazy var retrybutton: UIButton = {
        let retrybutton = UIButton()
        retrybutton.frame = CGRect(x: 220, y: 550, width: 162, height: 52)
        retrybutton.setImage(UIImage(named: "pred2_TRY_AGAIN"), for: .normal)
        retrybutton.addTarget(self, action: #selector(retrybuttontapped(_:)), for: .touchUpInside)
        return retrybutton
    }()
    
    public lazy var viewShadow6: UIView = {
        let viewShadow6 = UIView()
        viewShadow6.frame = CGRect(x: 220, y: 550, width: 162, height: 52)
        viewShadow6.backgroundColor = UIColor.white
        viewShadow6.layer.cornerRadius = 15
        viewShadow6.layer.shadowColor = UIColor.darkGray.cgColor
        viewShadow6.layer.shadowOpacity = 0.5
        viewShadow6.layer.shadowOffset = CGSize.zero
        viewShadow6.layer.shadowRadius = 20
        return viewShadow6
    }()
    
    public lazy var viewShadow_w: UIView = {
        let viewShadow_w = UIView()
        viewShadow_w.frame = CGRect(x: 107, y: 193, width: 140, height: 40)
        viewShadow_w.backgroundColor = UIColor.white
        viewShadow_w.layer.cornerRadius = 15
        viewShadow_w.layer.shadowColor = UIColor.darkGray.cgColor
        viewShadow_w.layer.shadowOpacity = 0.5
        viewShadow_w.layer.shadowOffset = CGSize.zero
        viewShadow_w.layer.shadowRadius = 20
        return viewShadow_w
    }()
    
    public lazy var viewShadow_s: UIView = {
        let viewShadow_s = UIView()
        viewShadow_s.frame = CGRect(x: 352, y: 193, width: 140, height: 40)
        viewShadow_s.backgroundColor = UIColor.white
        viewShadow_s.layer.cornerRadius = 15
        viewShadow_s.layer.shadowColor = UIColor.darkGray.cgColor
        viewShadow_s.layer.shadowOpacity = 0.5
        viewShadow_s.layer.shadowOffset = CGSize.zero
        viewShadow_s.layer.shadowRadius = 20
        return viewShadow_s
    }()
    
    public lazy var camShadow: UIView = {
        let camShadow = UIView()
        camShadow.frame = CGRect(x: 222, y: 332, width: 159, height: 45)
        camShadow.backgroundColor = UIColor.white
        camShadow.layer.cornerRadius = 5
        camShadow.layer.shadowColor = UIColor.darkGray.cgColor
        camShadow.layer.shadowOpacity = 0.35
        camShadow.layer.shadowOffset = CGSize.zero
        camShadow.layer.shadowRadius = 20
        return camShadow
    }()
    
    @objc func cambuttontapped(_ sender: UIButton){
        
        viewShadow5.backgroundColor = UIColor.white
        viewShadow5.layer.cornerRadius = 20
        viewShadow5.layer.shadowColor = UIColor.darkGray.cgColor
        viewShadow5.layer.shadowOpacity = 0.5
        viewShadow5.layer.shadowOffset = CGSize.zero
        viewShadow5.layer.shadowRadius = 20
        
        blurbgview.isHidden = false
        viewShadow5.isHidden = false
        yosemitebutton.isHidden = false
        capitanbutton.isHidden = false
        sierrabutton.isHidden = false
        hsierrabutton.isHidden = false
        testAbutton.isHidden = false
        testBbutton.isHidden = false
        testCbutton.isHidden = false
        camShadow.isHidden = true
        picselectview.isHidden = false
   
    }
    
    @objc func yosemitebuttontapped(_ sender: UIButton){
        
        blurbgview.isHidden = true
        viewShadow5.isHidden = true
        yosemitebutton.isHidden = true
        cambutton.isHidden = true
        capitanbutton.isHidden = true
        sierrabutton.isHidden = true
        hsierrabutton.isHidden = true
        retrybutton.isHidden = false
        viewShadow6.isHidden = false
        viewShadow_w.isHidden = false
        viewShadow_s.isHidden = false
        summerview.isHidden = false
        winterview.isHidden = false
        testAbutton.isHidden = true
        testBbutton.isHidden = true
        testCbutton.isHidden = true
        picselectview.isHidden = true
        
        guard let buffer = test1!.preprocess(image: test1!) else { return }
        guard let result = try? self.model.prediction(input_3__0: buffer) else { return }

        guard let result2 = try? self.model2.prediction(input_4__0: buffer) else { return }
        
        
        let resultimage: UIImage = result.conv2d_18__Tanh__0.image(min: -1, max: 1)!
        let resultview = UIImageView(image: resultimage)
        resultview.frame = CGRect(x: 74, y: 265, width: 207, height: 207)
        view.addSubview(resultview)
        
        
        let result2image: UIImage = result2.conv2d_26__Tanh__0.image(min: -1, max: 1)!
        let result2view = UIImageView(image: result2image)
        result2view.frame = CGRect(x: 318, y: 265, width: 207, height: 207)
        view.addSubview(result2view)
        
    }
    
    @objc func capitanbuttontapped(_ sender: UIButton){
        
        blurbgview.isHidden = true
        viewShadow5.isHidden = true
        yosemitebutton.isHidden = true
        cambutton.isHidden = true
        capitanbutton.isHidden = true
        sierrabutton.isHidden = true
        hsierrabutton.isHidden = true
        retrybutton.isHidden = false
        viewShadow6.isHidden = false
        viewShadow_w.isHidden = false
        viewShadow_s.isHidden = false
        summerview.isHidden = false
        winterview.isHidden = false
        testAbutton.isHidden = true
        testBbutton.isHidden = true
        testCbutton.isHidden = true
        picselectview.isHidden = true
        
        guard let buffer = test2!.preprocess(image: test2!) else { return }
        guard let result = try? self.model.prediction(input_3__0: buffer) else { return }

        guard let result2 = try? self.model2.prediction(input_4__0: buffer) else { return }
        
        
        let resultimage: UIImage = result.conv2d_18__Tanh__0.image(min: -1, max: 1)!
        let resultview = UIImageView(image: resultimage)
        resultview.frame = CGRect(x: 74, y: 265, width: 207, height: 207)
        view.addSubview(resultview)
        
        
        let result2image: UIImage = result2.conv2d_26__Tanh__0.image(min: -1, max: 1)!
        let result2view = UIImageView(image: result2image)
        result2view.frame = CGRect(x: 318, y: 265, width: 207, height: 207)
        view.addSubview(result2view)
        
    }
    
    @objc func sierrabuttontapped(_ sender: UIButton){
        
        blurbgview.isHidden = true
        viewShadow5.isHidden = true
        yosemitebutton.isHidden = true
        cambutton.isHidden = true
        capitanbutton.isHidden = true
        sierrabutton.isHidden = true
        hsierrabutton.isHidden = true
        retrybutton.isHidden = false
        viewShadow6.isHidden = false
        viewShadow_w.isHidden = false
        viewShadow_s.isHidden = false
        summerview.isHidden = false
        winterview.isHidden = false
        testAbutton.isHidden = true
        testBbutton.isHidden = true
        testCbutton.isHidden = true
        picselectview.isHidden = true
        
        guard let buffer = test3!.preprocess(image: test3!) else { return }
        guard let result = try? self.model.prediction(input_3__0: buffer) else { return }

        guard let result2 = try? self.model2.prediction(input_4__0: buffer) else { return }
        
        
        let resultimage: UIImage = result.conv2d_18__Tanh__0.image(min: -1, max: 1)!
        let resultview = UIImageView(image: resultimage)
        resultview.frame = CGRect(x: 74, y: 265, width: 207, height: 207)
        view.addSubview(resultview)
        
        
        let result2image: UIImage = result2.conv2d_26__Tanh__0.image(min: -1, max: 1)!
        let result2view = UIImageView(image: result2image)
        result2view.frame = CGRect(x: 318, y: 265, width: 207, height: 207)
        view.addSubview(result2view)
        
    }
    
    @objc func hsierrabuttontapped(_ sender: UIButton){
        
        blurbgview.isHidden = true
        viewShadow5.isHidden = true
        yosemitebutton.isHidden = true
        cambutton.isHidden = true
        capitanbutton.isHidden = true
        sierrabutton.isHidden = true
        hsierrabutton.isHidden = true
        retrybutton.isHidden = false
        viewShadow6.isHidden = false
        viewShadow_w.isHidden = false
        viewShadow_s.isHidden = false
        summerview.isHidden = false
        winterview.isHidden = false
        testAbutton.isHidden = true
        testBbutton.isHidden = true
        testCbutton.isHidden = true
        picselectview.isHidden = true
        
        guard let buffer = test4!.preprocess(image: test4!) else { return }
        guard let result = try? self.model.prediction(input_3__0: buffer) else { return }

        guard let result2 = try? self.model2.prediction(input_4__0: buffer) else { return }
        
        
        let resultimage: UIImage = result.conv2d_18__Tanh__0.image(min: -1, max: 1)!
        let resultview = UIImageView(image: resultimage)
        resultview.frame = CGRect(x: 74, y: 265, width: 207, height: 207)
        view.addSubview(resultview)
        
        
        let result2image: UIImage = result2.conv2d_26__Tanh__0.image(min: -1, max: 1)!
        let result2view = UIImageView(image: result2image)
        result2view.frame = CGRect(x: 318, y: 265, width: 207, height: 207)
        view.addSubview(result2view)
        
    }
    
    @objc func testAbuttontapped(_ sender: UIButton){
        
        blurbgview.isHidden = true
        viewShadow5.isHidden = true
        yosemitebutton.isHidden = true
        cambutton.isHidden = true
        capitanbutton.isHidden = true
        sierrabutton.isHidden = true
        hsierrabutton.isHidden = true
        retrybutton.isHidden = false
        viewShadow6.isHidden = false
        viewShadow_w.isHidden = false
        viewShadow_s.isHidden = false
        summerview.isHidden = false
        winterview.isHidden = false
        testAbutton.isHidden = true
        testBbutton.isHidden = true
        testCbutton.isHidden = true
        picselectview.isHidden = true
        
        guard let buffer = test5!.preprocess(image: test5!) else { return }
        guard let result = try? self.model.prediction(input_3__0: buffer) else { return }

        guard let result2 = try? self.model2.prediction(input_4__0: buffer) else { return }
        
        
        let resultimage: UIImage = result.conv2d_18__Tanh__0.image(min: -1, max: 1)!
        let resultview = UIImageView(image: resultimage)
        resultview.frame = CGRect(x: 74, y: 265, width: 207, height: 207)
        view.addSubview(resultview)
        
        
        let result2image: UIImage = result2.conv2d_26__Tanh__0.image(min: -1, max: 1)!
        let result2view = UIImageView(image: result2image)
        result2view.frame = CGRect(x: 318, y: 265, width: 207, height: 207)
        view.addSubview(result2view)
        
    }
    
    @objc func testBbuttontapped(_ sender: UIButton){
        
        blurbgview.isHidden = true
        viewShadow5.isHidden = true
        yosemitebutton.isHidden = true
        cambutton.isHidden = true
        capitanbutton.isHidden = true
        sierrabutton.isHidden = true
        hsierrabutton.isHidden = true
        retrybutton.isHidden = false
        viewShadow6.isHidden = false
        viewShadow_w.isHidden = false
        viewShadow_s.isHidden = false
        summerview.isHidden = false
        winterview.isHidden = false
        testAbutton.isHidden = true
        testBbutton.isHidden = true
        testCbutton.isHidden = true
        picselectview.isHidden = true
        
        guard let buffer = test6!.preprocess(image: test6!) else { return }
        guard let result = try? self.model.prediction(input_3__0: buffer) else { return }

        guard let result2 = try? self.model2.prediction(input_4__0: buffer) else { return }
        
        
        let resultimage: UIImage = result.conv2d_18__Tanh__0.image(min: -1, max: 1)!
        let resultview = UIImageView(image: resultimage)
        resultview.frame = CGRect(x: 74, y: 265, width: 207, height: 207)
        view.addSubview(resultview)
        
        
        let result2image: UIImage = result2.conv2d_26__Tanh__0.image(min: -1, max: 1)!
        let result2view = UIImageView(image: result2image)
        result2view.frame = CGRect(x: 318, y: 265, width: 207, height: 207)
        view.addSubview(result2view)
        
    }
    
    @objc func testCbuttontapped(_ sender: UIButton){
        
        blurbgview.isHidden = true
        viewShadow5.isHidden = true
        yosemitebutton.isHidden = true
        cambutton.isHidden = true
        capitanbutton.isHidden = true
        sierrabutton.isHidden = true
        hsierrabutton.isHidden = true
        retrybutton.isHidden = false
        viewShadow6.isHidden = false
        viewShadow_w.isHidden = false
        viewShadow_s.isHidden = false
        summerview.isHidden = false
        winterview.isHidden = false
        testAbutton.isHidden = true
        testBbutton.isHidden = true
        testCbutton.isHidden = true
        picselectview.isHidden = true
        
        guard let buffer = test7!.preprocess(image: test7!) else { return }
        guard let result = try? self.model.prediction(input_3__0: buffer) else { return }

        guard let result2 = try? self.model2.prediction(input_4__0: buffer) else { return }
        
        
        let resultimage: UIImage = result.conv2d_18__Tanh__0.image(min: -1, max: 1)!
        let resultview = UIImageView(image: resultimage)
        resultview.frame = CGRect(x: 74, y: 265, width: 207, height: 207)
        view.addSubview(resultview)
        
        
        let result2image: UIImage = result2.conv2d_26__Tanh__0.image(min: -1, max: 1)!
        let result2view = UIImageView(image: result2image)
        result2view.frame = CGRect(x: 318, y: 265, width: 207, height: 207)
        view.addSubview(result2view)
        
    }
    
    @objc func retrybuttontapped(_ sender: UIButton){
        view.addSubview(blurbgview)
        view.addSubview(viewShadow5)
        view.addSubview(yosemitebutton)
        view.addSubview(capitanbutton)
        view.addSubview(sierrabutton)
        view.addSubview(hsierrabutton)
        view.addSubview(testAbutton)
        view.addSubview(testBbutton)
        view.addSubview(testCbutton)
        view.addSubview(picselectview)

        blurbgview.isHidden = false
        viewShadow5.isHidden = false
        yosemitebutton.isHidden = false
        capitanbutton.isHidden = false
        sierrabutton.isHidden = false
        hsierrabutton.isHidden = false
        testAbutton.isHidden = false
        testBbutton.isHidden = false
        testCbutton.isHidden = false
        viewShadow_w.isHidden = true
        viewShadow_s.isHidden = true
        summerview.isHidden = true
        winterview.isHidden = true
        picselectview.isHidden = false
        
    }
    
    public lazy var nextbutton: UIButton = {
        let nextbutton = UIButton()
        nextbutton.frame = CGRect(x: 220, y: 639, width: 162, height: 52)
        nextbutton.setImage(UIImage(named: "next_pred"), for: .normal)
        nextbutton.addTarget(self, action: #selector(nextbuttontapped(_:)), for: .touchUpInside)
        return nextbutton
    }()
    
    @objc func nextbuttontapped(_ sender: UIButton){
        let nextview = Win4ViewController()
        navigationController?.pushViewController(nextview, animated: true)
    }
    
 
    public override func viewDidLoad() {
        
        super.viewDidLoad()
        let view = UIView(frame: CGRect(x: 0, y: 0, width: 600, height: 800))
        view.backgroundColor = .white
        view.alpha = 1
        self.view = view
        navigationController?.isNavigationBarHidden = true
        
        let arc = UIImage(named: "arc_pred.png")
        let arcview = UIImageView(image: arc!)
        arcview.frame = CGRect(x: 0, y: 4, width: 600, height: 796)
        view.addSubview(arcview)
        
        let title = UIImage(named: "Pred3_Title.png")
        let titleview = UIImageView(image: title!)
        titleview.frame = CGRect(x: 240, y: 60, width: 118, height: 19)
        view.addSubview(titleview)
        
        let viewShadow2 = UIView(frame: CGRect(x: 220, y: 639, width: 162, height: 52))
        viewShadow2.backgroundColor = UIColor.white
        viewShadow2.layer.cornerRadius = 15
        viewShadow2.layer.shadowColor = UIColor.darkGray.cgColor
        viewShadow2.layer.shadowOpacity = 0.5
        viewShadow2.layer.shadowOffset = CGSize.zero
        viewShadow2.layer.shadowRadius = 20
        
        let viewShadow_0 = UIView(frame: CGRect(x: 26, y: 149, width: 547, height: 366))
        viewShadow_0.backgroundColor = UIColor.white
        viewShadow_0.layer.cornerRadius = 15
        viewShadow_0.layer.shadowColor = UIColor.darkGray.cgColor
        viewShadow_0.layer.shadowOpacity = 0.5
        viewShadow_0.layer.shadowOffset = CGSize.zero
        viewShadow_0.layer.shadowRadius = 20
                
        view.addSubview(viewShadow2)
        view.addSubview(viewShadow_0)
        view.addSubview(nextbutton)
        view.addSubview(camShadow)
        view.addSubview(cambutton)
        view.addSubview(blurbgview)
        view.addSubview(viewShadow5)
        view.addSubview(yosemitebutton)
        view.addSubview(capitanbutton)
        view.addSubview(sierrabutton)
        view.addSubview(hsierrabutton)
        view.addSubview(testAbutton)
        view.addSubview(testBbutton)
        view.addSubview(testCbutton)
        view.addSubview(viewShadow6)
        view.addSubview(retrybutton)
        view.addSubview(viewShadow_s)
        view.addSubview(viewShadow_w)
        view.addSubview(summerview)
        view.addSubview(winterview)
        view.addSubview(picselectview)
        
        viewShadow5.isHidden = true
        blurbgview.isHidden = true
        yosemitebutton.isHidden = true
        capitanbutton.isHidden = true
        sierrabutton.isHidden = true
        hsierrabutton.isHidden = true
        retrybutton.isHidden = true
        viewShadow6.isHidden = true
        viewShadow_w.isHidden = true
        viewShadow_s.isHidden = true
        summerview.isHidden = true
        winterview.isHidden = true
        testAbutton.isHidden = true
        testBbutton.isHidden = true
        testCbutton.isHidden = true
        picselectview.isHidden = true
        
    }
    
}

extension UIImage {
    
    public func resize(to newSize: CGSize) -> UIImage {
                    UIGraphicsBeginImageContextWithOptions(CGSize(width: newSize.width, height: newSize.height), true, 1.0)
            self.draw(in: CGRect(x: 0, y: 0, width: newSize.width, height: newSize.height))
            let resizedImage = UIGraphicsGetImageFromCurrentImageContext()!
            UIGraphicsEndImageContext()
            
            return resizedImage
    }
    
    public func pixelData() -> [UInt8]? {
            let dataSize = size.width * size.height * 4
            var pixelData = [UInt8](repeating: 0, count: Int(dataSize))
            let colorSpace = CGColorSpaceCreateDeviceRGB()
            let context = CGContext(data: &pixelData, width: Int(size.width), height: Int(size.height), bitsPerComponent: 8, bytesPerRow: 4 * Int(size.width), space: colorSpace, bitmapInfo: CGImageAlphaInfo.noneSkipLast.rawValue)
            
            guard let cgImage = self.cgImage else { return nil }
            context?.draw(cgImage, in: CGRect(x: 0, y: 0, width: size.width, height: size.height))
            
            return pixelData
    }
    
    func preprocess(image: UIImage) -> MLMultiArray? {
        let size = CGSize(width: 256, height: 256)
        
        
        guard let pixels = image.resize(to: size).pixelData()?.map({ (Double($0) / 255.0 - 0.5) * 2 }) else {
            return nil
        }

        guard let array = try? MLMultiArray(shape: [3, 256, 256], dataType: .double) else {
            return nil
        }
        
        let r = pixels.enumerated().filter { $0.offset % 4 == 0 }.map { $0.element }
        let g = pixels.enumerated().filter { $0.offset % 4 == 1 }.map { $0.element }
        let b = pixels.enumerated().filter { $0.offset % 4 == 2 }.map { $0.element }

        let combination = r + g + b
        for (index, element) in combination.enumerated() {
            array[index] = NSNumber(value: element)
        }

        return array
    }
        
}
