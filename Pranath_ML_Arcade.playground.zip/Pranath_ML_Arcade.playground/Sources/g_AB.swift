import UIKit
import PlaygroundSupport
import Vision

import CoreML

// ****************** code for A2B generator ******************

/// Model Prediction Input Type
@available(macOS 10.13, iOS 11.0, tvOS 11.0, watchOS 4.0, *)
public class g_ABInput : MLFeatureProvider {

    /// input_3__0 as 3 x 256 x 256 3-dimensional array of doubles
    var input_3__0: MLMultiArray

    public var featureNames: Set<String> {
        get {
            return ["input_3__0"]
        }
    }
    
    public func featureValue(for featureName: String) -> MLFeatureValue? {
        if (featureName == "input_3__0") {
            return MLFeatureValue(multiArray: input_3__0)
        }
        return nil
    }
    
    public init(input_3__0: MLMultiArray) {
        self.input_3__0 = input_3__0
    }
}

/// Model Prediction Output Type
@available(macOS 10.13, iOS 11.0, tvOS 11.0, watchOS 4.0, *)
public class g_ABOutput : MLFeatureProvider {

    /// Source provided by CoreML

    private let provider : MLFeatureProvider


    /// conv2d_18__Tanh__0 as 3 x 256 x 256 3-dimensional array of doubles
    public lazy var conv2d_18__Tanh__0: MLMultiArray = {
        [unowned self] in return self.provider.featureValue(for: "conv2d_18__Tanh__0")!.multiArrayValue
    }()!

    public var featureNames: Set<String> {
        return self.provider.featureNames
    }
    
    public func featureValue(for featureName: String) -> MLFeatureValue? {
        return self.provider.featureValue(for: featureName)
    }

    public init(conv2d_18__Tanh__0: MLMultiArray) {
        self.provider = try! MLDictionaryFeatureProvider(dictionary: ["conv2d_18__Tanh__0" : MLFeatureValue(multiArray: conv2d_18__Tanh__0)])
    }

    public init(features: MLFeatureProvider) {
        self.provider = features
    }
}


/// Class for model loading and prediction
@available(macOS 10.13, iOS 11.0, tvOS 11.0, watchOS 4.0, *)
public class g_AB {
    var model: MLModel

/// URL of model assuming it was installed in the same bundle as this class
    public class var urlOfModelInThisBundle : URL {
        let bundle = Bundle(for: g_AB.self)
        return bundle.url(forResource: "g_AB", withExtension:"mlmodelc")!
    }

    /**
        Construct a model with explicit path to mlmodelc file
        - parameters:
           - url: the file url of the model
           - throws: an NSError object that describes the problem
    */
    public init(contentsOf url: URL) throws {
        self.model = try MLModel(contentsOf: url)
    }

    /// Construct a model that automatically loads the model from the app's bundle
    convenience init() {
        try! self.init(contentsOf: type(of:self).urlOfModelInThisBundle)
    }

    /**
        Construct a model with configuration
        - parameters:
           - configuration: the desired model configuration
           - throws: an NSError object that describes the problem
    */
    @available(macOS 10.14, iOS 12.0, tvOS 12.0, watchOS 5.0, *)
    convenience init(configuration: MLModelConfiguration) throws {
        try self.init(contentsOf: type(of:self).urlOfModelInThisBundle, configuration: configuration)
    }

    /**
        Construct a model with explicit path to mlmodelc file and configuration
        - parameters:
           - url: the file url of the model
           - configuration: the desired model configuration
           - throws: an NSError object that describes the problem
    */
    @available(macOS 10.14, iOS 12.0, tvOS 12.0, watchOS 5.0, *)
    init(contentsOf url: URL, configuration: MLModelConfiguration) throws {
        self.model = try MLModel(contentsOf: url, configuration: configuration)
    }

    /**
        Make a prediction using the structured interface
        - parameters:
           - input: the input to the prediction as g_ABInput
        - throws: an NSError object that describes the problem
        - returns: the result of the prediction as g_ABOutput
    */
    func prediction(input: g_ABInput) throws -> g_ABOutput {
        return try self.prediction(input: input, options: MLPredictionOptions())
    }

    /**
        Make a prediction using the structured interface
        - parameters:
           - input: the input to the prediction as g_ABInput
           - options: prediction options
        - throws: an NSError object that describes the problem
        - returns: the result of the prediction as g_ABOutput
    */
    func prediction(input: g_ABInput, options: MLPredictionOptions) throws -> g_ABOutput {
        let outFeatures = try model.prediction(from: input, options:options)
        return g_ABOutput(features: outFeatures)
    }

    /**
        Make a prediction using the convenience interface
        - parameters:
            - input_3__0 as 3 x 256 x 256 3-dimensional array of doubles
        - throws: an NSError object that describes the problem
        - returns: the result of the prediction as g_ABOutput
    */
    func prediction(input_3__0: MLMultiArray) throws -> g_ABOutput {
        let input_ = g_ABInput(input_3__0: input_3__0)
        return try self.prediction(input: input_)
    }

    /**
        Make a batch prediction using the structured interface
        - parameters:
           - inputs: the inputs to the prediction as [g_ABInput]
           - options: prediction options
        - throws: an NSError object that describes the problem
        - returns: the result of the prediction as [g_ABOutput]
    */
    @available(macOS 10.14, iOS 12.0, tvOS 12.0, watchOS 5.0, *)
    func predictions(inputs: [g_ABInput], options: MLPredictionOptions = MLPredictionOptions()) throws -> [g_ABOutput] {
        let batchIn = MLArrayBatchProvider(array: inputs)
        let batchOut = try model.predictions(from: batchIn, options: options)
        var results : [g_ABOutput] = []
        results.reserveCapacity(inputs.count)
        for i in 0..<batchOut.count {
            let outProvider = batchOut.features(at: i)
            let result =  g_ABOutput(features: outProvider)
            results.append(result)
        }
        return results
    }
}
