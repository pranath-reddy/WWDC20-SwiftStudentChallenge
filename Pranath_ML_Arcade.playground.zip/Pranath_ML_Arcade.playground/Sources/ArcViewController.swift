import UIKit
import PlaygroundSupport

class ArcViewController: UIViewController {
    
    public lazy var Arcnextbutton: UIButton = {
        let Arcnextbutton = UIButton()
        Arcnextbutton.frame = CGRect(x: 237, y: 710, width: 127, height: 46)
        Arcnextbutton.setImage(UIImage(named: "info_button"), for: .normal)
        Arcnextbutton.addTarget(self, action: #selector(Arcnextbuttontapped(_:)), for: .touchUpInside)
        return Arcnextbutton
    }()  
    
    @objc func Arcnextbuttontapped(_ sender: UIButton){
        let nextview = InfoViewController()
        navigationController?.pushViewController(nextview, animated: true)
    }
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        let view = UIView(frame: CGRect(x: 0, y: 0, width: 600, height: 800))
        view.backgroundColor = .white
        view.alpha = 1
        self.view = view
        navigationController?.isNavigationBarHidden = true

        let srect1 = UIView(frame: CGRect(x: 36, y: 98, width: 66, height: 66))
        srect1.backgroundColor = UIColor.white
        srect1.layer.cornerRadius = 15
        srect1.layer.shadowColor = UIColor.darkGray.cgColor
        srect1.layer.shadowOpacity = 0.35
        srect1.layer.shadowOffset = CGSize.zero
        srect1.layer.shadowRadius = 20
        
        let srect2 = UIView(frame: CGRect(x: 322, y: 98, width: 66, height: 66))
        srect2.backgroundColor = UIColor.white
        srect2.layer.cornerRadius = 15
        srect2.layer.shadowColor = UIColor.darkGray.cgColor
        srect2.layer.shadowOpacity = 0.35
        srect2.layer.shadowOffset = CGSize.zero
        srect2.layer.shadowRadius = 20
        
        let srect3 = UIView(frame: CGRect(x: 36, y: 410, width: 66, height: 66))
        srect3.backgroundColor = UIColor.white
        srect3.layer.cornerRadius = 15
        srect3.layer.shadowColor = UIColor.darkGray.cgColor
        srect3.layer.shadowOpacity = 0.35
        srect3.layer.shadowOffset = CGSize.zero
        srect3.layer.shadowRadius = 20
        
        let srect4 = UIView(frame: CGRect(x: 322, y: 410, width: 66, height: 66))
        srect4.backgroundColor = UIColor.white
        srect4.layer.cornerRadius = 15
        srect4.layer.shadowColor = UIColor.darkGray.cgColor
        srect4.layer.shadowOpacity = 0.35
        srect4.layer.shadowOffset = CGSize.zero
        srect4.layer.shadowRadius = 20
        
        let brect1 = UIView(frame: CGRect(x: 36, y: 131, width: 243, height: 243))
        brect1.backgroundColor = UIColor.white
        brect1.layer.cornerRadius = 15
        brect1.layer.shadowColor = UIColor.darkGray.cgColor
        brect1.layer.shadowOpacity = 0.35
        brect1.layer.shadowOffset = CGSize.zero
        brect1.layer.shadowRadius = 20
        
        let brect2 = UIView(frame: CGRect(x: 322, y: 131, width: 243, height: 243))
        brect2.backgroundColor = UIColor.white
        brect2.layer.cornerRadius = 15
        brect2.layer.shadowColor = UIColor.darkGray.cgColor
        brect2.layer.shadowOpacity = 0.35
        brect2.layer.shadowOffset = CGSize.zero
        brect2.layer.shadowRadius = 20
        
        let brect3 = UIView(frame: CGRect(x: 36, y: 443, width: 243, height: 243))
        brect3.backgroundColor = UIColor.white
        brect3.layer.cornerRadius = 15
        brect3.layer.shadowColor = UIColor.darkGray.cgColor
        brect3.layer.shadowOpacity = 0.35
        brect3.layer.shadowOffset = CGSize.zero
        brect3.layer.shadowRadius = 20
        
        let brect4 = UIView(frame: CGRect(x: 322, y: 443, width: 243, height: 243))
        brect4.backgroundColor = UIColor.white
        brect4.layer.cornerRadius = 15
        brect4.layer.shadowColor = UIColor.darkGray.cgColor
        brect4.layer.shadowOpacity = 0.35
        brect4.layer.shadowOffset = CGSize.zero
        brect4.layer.shadowRadius = 20
        
        let viewShadow8 = UIView(frame: CGRect(x: 237, y: 710, width: 127, height: 46))
        viewShadow8.backgroundColor = UIColor.white
        viewShadow8.layer.cornerRadius = 15
        viewShadow8.layer.shadowColor = UIColor.darkGray.cgColor
        viewShadow8.layer.shadowOpacity = 0.35
        viewShadow8.layer.shadowOffset = CGSize.zero
        viewShadow8.layer.shadowRadius = 20
 
        let title = UIImage(named: "Arcade_Text.png")
        let titleview = UIImageView(image: title!)
        titleview.frame = CGRect(x: 0, y: 0, width: 600, height: 800)
        
        let arc = UIImage(named: "arc_win2.png")
        let arcview = UIImageView(image: arc!)
        arcview.frame = CGRect(x: 0, y: -159, width: 958, height: 958)
        view.addSubview(arcview)
        
        view.addSubview(brect1)
        view.addSubview(brect2)
        view.addSubview(brect3)
        view.addSubview(brect4)
        view.addSubview(srect1)
        view.addSubview(srect2)
        view.addSubview(srect3)
        view.addSubview(srect4)
        view.addSubview(titleview)
        
        view.addSubview(viewShadow8)
        view.addSubview(Arcnextbutton)
    }
    
}
