import UIKit
import PlaygroundSupport

class Win2ViewController: UIViewController {
    
    public lazy var win2nextbutton: UIButton = {
        let win2nextbutton = UIButton()
        win2nextbutton.frame = CGRect(x: 237, y: 681, width: 127, height: 46)
        win2nextbutton.setImage(UIImage(named: "info_button"), for: .normal)
        win2nextbutton.addTarget(self, action: #selector(win2nextbuttontapped(_:)), for: .touchUpInside)
        return win2nextbutton
    }()
    
    @objc func win2nextbuttontapped(_ sender: UIButton){
        let nextview = Pred2ViewController()
        navigationController?.pushViewController(nextview, animated: true)
    }
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        let view = UIView(frame: CGRect(x: 0, y: 0, width: 600, height: 800))
        view.backgroundColor = .white
        view.alpha = 1
        self.view = view
        navigationController?.isNavigationBarHidden = true

        let srect = UIView()
        srect.frame = CGRect(x: 281, y: 357, width: 38, height: 7)
        srect.clipsToBounds = true
        srect.layer.cornerRadius = 3
        srect.backgroundColor = UIColor(red: 0.70, green: 0.81, blue: 0.96, alpha: 1)
        srect.alpha = 1
        
        // happy
        let viewShadow = UIView(frame: CGRect(x: 60, y: 386, width: 92, height: 92))
        viewShadow.backgroundColor = UIColor.white
        viewShadow.layer.cornerRadius = 15
        viewShadow.layer.shadowColor = UIColor.darkGray.cgColor
        viewShadow.layer.shadowOpacity = 0.35
        viewShadow.layer.shadowOffset = CGSize.zero
        viewShadow.layer.shadowRadius = 20

        // neutral
        let viewShadow2 = UIView(frame: CGRect(x: 183, y: 386, width: 93, height: 92))
        viewShadow2.backgroundColor = UIColor.white
        viewShadow2.layer.cornerRadius = 15
        viewShadow2.layer.shadowColor = UIColor.darkGray.cgColor
        viewShadow2.layer.shadowOpacity = 0.35
        viewShadow2.layer.shadowOffset = CGSize.zero
        viewShadow2.layer.shadowRadius = 20

        // angry
        let viewShadow3 = UIView(frame: CGRect(x: 314, y: 386, width: 92, height: 92))
        viewShadow3.backgroundColor = UIColor.white
        viewShadow3.layer.cornerRadius = 15
        viewShadow3.layer.shadowColor = UIColor.darkGray.cgColor
        viewShadow3.layer.shadowOpacity = 0.35
        viewShadow3.layer.shadowOffset = CGSize.zero
        viewShadow3.layer.shadowRadius = 20
        
        // sad
        let viewShadow4 = UIView(frame: CGRect(x: 448, y: 386, width: 92, height: 92))
        viewShadow4.backgroundColor = UIColor.white
        viewShadow4.layer.cornerRadius = 15
        viewShadow4.layer.shadowColor = UIColor.darkGray.cgColor
        viewShadow4.layer.shadowOpacity = 0.35
        viewShadow4.layer.shadowOffset = CGSize.zero
        viewShadow4.layer.shadowRadius = 20
        
        // disgust
        let viewShadow5 = UIView(frame: CGRect(x: 117, y: 527, width: 93, height: 92))
        viewShadow5.backgroundColor = UIColor.white
        viewShadow5.layer.cornerRadius = 15
        viewShadow5.layer.shadowColor = UIColor.darkGray.cgColor
        viewShadow5.layer.shadowOpacity = 0.35
        viewShadow5.layer.shadowOffset = CGSize.zero
        viewShadow5.layer.shadowRadius = 20
        
        // scared
        let viewShadow6 = UIView(frame: CGRect(x: 254, y: 527, width: 92, height: 92))
        viewShadow6.backgroundColor = UIColor.white
        viewShadow6.layer.cornerRadius = 15
        viewShadow6.layer.shadowColor = UIColor.darkGray.cgColor
        viewShadow6.layer.shadowOpacity = 0.35
        viewShadow6.layer.shadowOffset = CGSize.zero
        viewShadow6.layer.shadowRadius = 20
        
        // surprise
        let viewShadow7 = UIView(frame: CGRect(x: 394, y: 527, width: 92, height: 92))
        viewShadow7.backgroundColor = UIColor.white
        viewShadow7.layer.cornerRadius = 15
        viewShadow7.layer.shadowColor = UIColor.darkGray.cgColor
        viewShadow7.layer.shadowOpacity = 0.35
        viewShadow7.layer.shadowOffset = CGSize.zero
        viewShadow7.layer.shadowRadius = 20
        
        // button
        let viewShadow8 = UIView(frame: CGRect(x: 237, y: 681, width: 127, height: 46))
        viewShadow8.backgroundColor = UIColor.white
        viewShadow8.layer.cornerRadius = 15
        viewShadow8.layer.shadowColor = UIColor.darkGray.cgColor
        viewShadow8.layer.shadowOpacity = 0.35
        viewShadow8.layer.shadowOffset = CGSize.zero
        viewShadow8.layer.shadowRadius = 20
 
        let title = UIImage(named: "win2title.png")
        let titleview = UIImageView(image: title!)
        titleview.frame = CGRect(x: 170, y: 148, width: 259, height: 91)
        view.addSubview(titleview)
        
        let title2 = UIImage(named: "mood_chart.png")
        let title2view = UIImageView(image: title2!)
        title2view.frame = CGRect(x: 247, y: 327, width: 108, height: 14)
        view.addSubview(title2view)

        let happy = UIImage(named: "happy.png")
        let happyview = UIImageView(image: happy!)
        happyview.frame = CGRect(x: 84, y: 399, width: 44, height: 66)
        
        let neutral = UIImage(named: "neutral.png")
        let neutralview = UIImageView(image: neutral!)
        neutralview.frame = CGRect(x: 203, y: 398, width: 50, height: 67)
        
        let angry = UIImage(named: "angry.png")
        let angryview = UIImageView(image: angry!)
        angryview.frame = CGRect(x: 336, y: 397, width: 48, height: 70)
        
        let sad = UIImage(named: "sad.png")
        let sadview = UIImageView(image: sad!)
        sadview.frame = CGRect(x: 471, y: 396, width: 47, height: 71)
        
        let disgust = UIImage(named: "disgust.png")
        let disgustview = UIImageView(image: disgust!)
        disgustview.frame = CGRect(x: 139, y: 541, width: 49, height: 66)
        
        let scared = UIImage(named: "scared.png")
        let scaredview = UIImageView(image: scared!)
        scaredview.frame = CGRect(x: 276, y: 539, width: 47, height: 69)
        
        let surprise = UIImage(named: "surprise.png")
        let surpriseview = UIImageView(image: surprise!)
        surpriseview.frame = CGRect(x: 412, y: 540, width: 56, height: 68)
        
        let arc = UIImage(named: "arc_win2.png")
        let arcview = UIImageView(image: arc!)
        arcview.frame = CGRect(x: 0, y: -159, width: 958, height: 958)
        
        view.addSubview(arcview)
        view.addSubview(viewShadow)
        view.addSubview(viewShadow2)
        view.addSubview(viewShadow3)
        view.addSubview(viewShadow4)
        view.addSubview(viewShadow5)
        view.addSubview(viewShadow6)
        view.addSubview(viewShadow7)
        view.addSubview(srect)
        view.addSubview(happyview)
        view.addSubview(neutralview)
        view.addSubview(angryview)
        view.addSubview(sadview)
        view.addSubview(disgustview)
        view.addSubview(scaredview)
        view.addSubview(surpriseview)
        view.addSubview(viewShadow8)
        view.addSubview(win2nextbutton)
    }
    
}
